#pragma once
#include <iostream>
#include <vector>
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <cctype>
#include <list>
#include <cstdlib>

namespace Pr2JoseRecinos1270421 {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;


	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::Button^ button5;
	private: System::Windows::Forms::Button^ button6;

	private: System::Windows::Forms::Button^ button8;
	private: System::Windows::Forms::Button^ button9;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::TextBox^ textBox3;




	private: System::Windows::Forms::TextBox^ textBox29;
	private: System::Windows::Forms::TextBox^ textBox30;

	private: System::Windows::Forms::TextBox^ textBox7;
	private: System::Windows::Forms::TextBox^ textBox8;
	private: System::Windows::Forms::TextBox^ textBox9;

	private: System::Windows::Forms::TextBox^ textBox11;
	private: System::Windows::Forms::TextBox^ textBox12;
	private: System::Windows::Forms::TextBox^ textBox13;
	private: System::Windows::Forms::TextBox^ textBox14;
	private: System::Windows::Forms::TextBox^ textBox15;
	private: System::Windows::Forms::TextBox^ textBox16;
	private: System::Windows::Forms::TextBox^ textBox17;
	private: System::Windows::Forms::TextBox^ textBox18;
	private: System::Windows::Forms::TextBox^ textBox19;
	private: System::Windows::Forms::TextBox^ textBox20;
	private: System::Windows::Forms::TextBox^ textBox21;
	private: System::Windows::Forms::TextBox^ textBox22;
	private: System::Windows::Forms::TextBox^ textBox23;
	private: System::Windows::Forms::TextBox^ textBox24;
	private: System::Windows::Forms::TextBox^ textBox25;
	private: System::Windows::Forms::TextBox^ textBox26;
	private: System::Windows::Forms::TextBox^ textBox27;
	private: System::Windows::Forms::TextBox^ textBox28;
	private: System::Windows::Forms::TextBox^ textBox33;
	private: System::Windows::Forms::TextBox^ textBox32;



	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Label^ label26;
	private: System::Windows::Forms::Label^ label27;
	private: System::Windows::Forms::Label^ label25;






	private: System::Windows::Forms::Label^ label24;







	private: System::Windows::Forms::Label^ label23;


	private: System::Windows::Forms::Label^ label21;


	private: System::Windows::Forms::Label^ label20;


	private: System::Windows::Forms::Label^ label31;


	private: System::Windows::Forms::Label^ label29;


	private: System::Windows::Forms::Label^ label28;


	private: System::Windows::Forms::Label^ label13;


	private: System::Windows::Forms::Label^ label12;
private: System::Windows::Forms::Label^ label22;



private: System::Windows::Forms::Label^ label19;

private: System::Windows::Forms::Label^ label18;

private: System::Windows::Forms::Label^ label2;

	private: System::Windows::Forms::Label^ label16;
private: System::Windows::Forms::Label^ label15;
private: System::Windows::Forms::Label^ label14;



private: System::Windows::Forms::Label^ label6;









private: System::Windows::Forms::Label^ label5;


private: System::Windows::Forms::Label^ label4;
private: System::Windows::Forms::Label^ label10;

private: System::Windows::Forms::Label^ label32;





private: System::Windows::Forms::Label^ label30;
private: System::Windows::Forms::Label^ label34;






private: System::Windows::Forms::Label^ label33;




	private: System::Windows::Forms::Label^ label35;
private: System::Windows::Forms::Label^ label37;



private: System::Windows::Forms::Label^ label1;

private: System::Windows::Forms::Label^ label3;
private: System::Windows::Forms::ListBox^ listNombreE;
private: System::Windows::Forms::ListBox^ listApellidoE;
private: System::Windows::Forms::ListBox^ listDPIE;
private: System::Windows::Forms::ListBox^ listGrado;
private: System::Windows::Forms::ListBox^ listCentroTrabajo;
private: System::Windows::Forms::ListBox^ listEstudio;
private: System::Windows::Forms::ListBox^ listCarrera;
private: System::Windows::Forms::ListBox^ listAnio;
private: System::Windows::Forms::ListBox^ listC1E;
private: System::Windows::Forms::ListBox^ listC2E;
private: System::Windows::Forms::ListBox^ listNC1E;
private: System::Windows::Forms::ListBox^ listNC2E;
private: System::Windows::Forms::ListBox^ listPromE;
private: System::Windows::Forms::ListBox^ listC4;
private: System::Windows::Forms::ListBox^ listBoxC3;
private: System::Windows::Forms::ListBox^ listC5;
private: System::Windows::Forms::ListBox^ listNC3;
private: System::Windows::Forms::ListBox^ listNC4;
private: System::Windows::Forms::ListBox^ listNC5;
private: System::Windows::Forms::ListBox^ listfacultad;
private: System::Windows::Forms::ListBox^ listMuestraVF;
private: System::Windows::Forms::ListBox^ listBox1;
private: System::Windows::Forms::ListBox^ listBox2;
private: System::Windows::Forms::ListBox^ listBox3;
private: System::Windows::Forms::ListBox^ listBox4;
private: System::Windows::Forms::ListBox^ listBox5;
private: System::Windows::Forms::ListBox^ listBox6;
private: System::Windows::Forms::ListBox^ listBox7;
private: System::Windows::Forms::ListBox^ listBox8;
private: System::Windows::Forms::ListBox^ listBox9;
private: System::Windows::Forms::ListBox^ listBox10;
private: System::Windows::Forms::ListBox^ listBox11;
private: System::Windows::Forms::ListBox^ listBox12;
private: System::Windows::Forms::ListBox^ listBox13;
private: System::Windows::Forms::ListBox^ listBox14;
private: System::Windows::Forms::TextBox^ textBox31;
private: System::Windows::Forms::TextBox^ textBox6;
private: System::Windows::Forms::ComboBox^ comboBox3;
private: System::Windows::Forms::TextBox^ textBox4;
private: System::Windows::Forms::TextBox^ textBox5;
private: System::Windows::Forms::Label^ label11;
private: System::Windows::Forms::Label^ label9;
private: System::Windows::Forms::Button^ button7;
private: System::Windows::Forms::TextBox^ textBox10;
private: System::Windows::Forms::ComboBox^ comboBox1;
private: System::Windows::Forms::ComboBox^ comboBox2;
private: System::Windows::Forms::GroupBox^ groupBox1;
private: System::Windows::Forms::GroupBox^ groupBox2;

private: System::Windows::Forms::ComboBox^ comboBox4;
private: System::Windows::Forms::Button^ button10;
private: System::Windows::Forms::Label^ label36;





	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox29 = (gcnew System::Windows::Forms::TextBox());
			this->textBox30 = (gcnew System::Windows::Forms::TextBox());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->textBox11 = (gcnew System::Windows::Forms::TextBox());
			this->textBox12 = (gcnew System::Windows::Forms::TextBox());
			this->textBox13 = (gcnew System::Windows::Forms::TextBox());
			this->textBox14 = (gcnew System::Windows::Forms::TextBox());
			this->textBox15 = (gcnew System::Windows::Forms::TextBox());
			this->textBox16 = (gcnew System::Windows::Forms::TextBox());
			this->textBox17 = (gcnew System::Windows::Forms::TextBox());
			this->textBox18 = (gcnew System::Windows::Forms::TextBox());
			this->textBox19 = (gcnew System::Windows::Forms::TextBox());
			this->textBox20 = (gcnew System::Windows::Forms::TextBox());
			this->textBox21 = (gcnew System::Windows::Forms::TextBox());
			this->textBox22 = (gcnew System::Windows::Forms::TextBox());
			this->textBox23 = (gcnew System::Windows::Forms::TextBox());
			this->textBox24 = (gcnew System::Windows::Forms::TextBox());
			this->textBox25 = (gcnew System::Windows::Forms::TextBox());
			this->textBox26 = (gcnew System::Windows::Forms::TextBox());
			this->textBox27 = (gcnew System::Windows::Forms::TextBox());
			this->textBox28 = (gcnew System::Windows::Forms::TextBox());
			this->textBox33 = (gcnew System::Windows::Forms::TextBox());
			this->textBox32 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->listNombreE = (gcnew System::Windows::Forms::ListBox());
			this->listApellidoE = (gcnew System::Windows::Forms::ListBox());
			this->listDPIE = (gcnew System::Windows::Forms::ListBox());
			this->listGrado = (gcnew System::Windows::Forms::ListBox());
			this->listCentroTrabajo = (gcnew System::Windows::Forms::ListBox());
			this->listEstudio = (gcnew System::Windows::Forms::ListBox());
			this->listCarrera = (gcnew System::Windows::Forms::ListBox());
			this->listAnio = (gcnew System::Windows::Forms::ListBox());
			this->listC1E = (gcnew System::Windows::Forms::ListBox());
			this->listC2E = (gcnew System::Windows::Forms::ListBox());
			this->listNC1E = (gcnew System::Windows::Forms::ListBox());
			this->listNC2E = (gcnew System::Windows::Forms::ListBox());
			this->listPromE = (gcnew System::Windows::Forms::ListBox());
			this->listC4 = (gcnew System::Windows::Forms::ListBox());
			this->listBoxC3 = (gcnew System::Windows::Forms::ListBox());
			this->listC5 = (gcnew System::Windows::Forms::ListBox());
			this->listNC3 = (gcnew System::Windows::Forms::ListBox());
			this->listNC4 = (gcnew System::Windows::Forms::ListBox());
			this->listNC5 = (gcnew System::Windows::Forms::ListBox());
			this->listfacultad = (gcnew System::Windows::Forms::ListBox());
			this->listMuestraVF = (gcnew System::Windows::Forms::ListBox());
			this->listBox1 = (gcnew System::Windows::Forms::ListBox());
			this->listBox2 = (gcnew System::Windows::Forms::ListBox());
			this->listBox3 = (gcnew System::Windows::Forms::ListBox());
			this->listBox4 = (gcnew System::Windows::Forms::ListBox());
			this->listBox5 = (gcnew System::Windows::Forms::ListBox());
			this->listBox6 = (gcnew System::Windows::Forms::ListBox());
			this->listBox7 = (gcnew System::Windows::Forms::ListBox());
			this->listBox8 = (gcnew System::Windows::Forms::ListBox());
			this->listBox9 = (gcnew System::Windows::Forms::ListBox());
			this->listBox10 = (gcnew System::Windows::Forms::ListBox());
			this->listBox11 = (gcnew System::Windows::Forms::ListBox());
			this->listBox12 = (gcnew System::Windows::Forms::ListBox());
			this->listBox13 = (gcnew System::Windows::Forms::ListBox());
			this->listBox14 = (gcnew System::Windows::Forms::ListBox());
			this->textBox31 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::MediumPurple;
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(587, 21);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"BuscarDPI";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::Color::MediumPurple;
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button2->Location = System::Drawing::Point(183, 19);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Eliminar";
			this->button2->UseVisualStyleBackColor = false;
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::Color::MediumPurple;
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button3->Location = System::Drawing::Point(53, 12);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(199, 27);
			this->button3->TabIndex = 2;
			this->button3->Text = L"Crear CSV Estudiantes Doctorado";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::MediumPurple;
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button4->Location = System::Drawing::Point(100, 45);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(100, 33);
			this->button4->TabIndex = 3;
			this->button4->Text = L"SalarioPromedio";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::MediumPurple;
			this->button5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button5->Location = System::Drawing::Point(19, 19);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 23);
			this->button5->TabIndex = 4;
			this->button5->Text = L"Agregar";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::MediumPurple;
			this->button6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button6->Location = System::Drawing::Point(100, 19);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(75, 23);
			this->button6->TabIndex = 5;
			this->button6->Text = L"Modificar";
			this->button6->UseVisualStyleBackColor = false;
			// 
			// button8
			// 
			this->button8->BackColor = System::Drawing::Color::MediumPurple;
			this->button8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button8->Location = System::Drawing::Point(187, 132);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(126, 28);
			this->button8->TabIndex = 7;
			this->button8->Text = L"InformacionDeCursos";
			this->button8->UseVisualStyleBackColor = false;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button9
			// 
			this->button9->BackColor = System::Drawing::Color::MediumPurple;
			this->button9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button9->Location = System::Drawing::Point(177, 176);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(136, 33);
			this->button9->TabIndex = 8;
			this->button9->Text = L"NotaMasAltaYPromedio";
			this->button9->UseVisualStyleBackColor = false;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// textBox1
			// 
			this->textBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox1->Location = System::Drawing::Point(146, 404);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 9;
			this->textBox1->Visible = false;
			// 
			// textBox2
			// 
			this->textBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox2->Location = System::Drawing::Point(262, 404);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 10;
			this->textBox2->Visible = false;
			// 
			// textBox3
			// 
			this->textBox3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox3->Location = System::Drawing::Point(378, 404);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(100, 20);
			this->textBox3->TabIndex = 11;
			this->textBox3->Visible = false;
			// 
			// textBox29
			// 
			this->textBox29->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox29->Location = System::Drawing::Point(400, 487);
			this->textBox29->Name = L"textBox29";
			this->textBox29->Size = System::Drawing::Size(100, 20);
			this->textBox29->TabIndex = 16;
			this->textBox29->Visible = false;
			// 
			// textBox30
			// 
			this->textBox30->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox30->Location = System::Drawing::Point(426, 21);
			this->textBox30->Name = L"textBox30";
			this->textBox30->Size = System::Drawing::Size(155, 20);
			this->textBox30->TabIndex = 17;
			// 
			// textBox7
			// 
			this->textBox7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox7->Location = System::Drawing::Point(166, 517);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(100, 20);
			this->textBox7->TabIndex = 18;
			this->textBox7->Visible = false;
			// 
			// textBox8
			// 
			this->textBox8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox8->Location = System::Drawing::Point(166, 543);
			this->textBox8->Name = L"textBox8";
			this->textBox8->Size = System::Drawing::Size(100, 20);
			this->textBox8->TabIndex = 19;
			this->textBox8->Visible = false;
			// 
			// textBox9
			// 
			this->textBox9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox9->Location = System::Drawing::Point(371, 514);
			this->textBox9->Name = L"textBox9";
			this->textBox9->Size = System::Drawing::Size(100, 20);
			this->textBox9->TabIndex = 20;
			this->textBox9->Visible = false;
			// 
			// textBox11
			// 
			this->textBox11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox11->Location = System::Drawing::Point(715, 409);
			this->textBox11->Name = L"textBox11";
			this->textBox11->Size = System::Drawing::Size(100, 20);
			this->textBox11->TabIndex = 22;
			this->textBox11->Visible = false;
			// 
			// textBox12
			// 
			this->textBox12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox12->Location = System::Drawing::Point(821, 409);
			this->textBox12->Name = L"textBox12";
			this->textBox12->Size = System::Drawing::Size(100, 20);
			this->textBox12->TabIndex = 23;
			this->textBox12->Visible = false;
			// 
			// textBox13
			// 
			this->textBox13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox13->Location = System::Drawing::Point(927, 409);
			this->textBox13->Name = L"textBox13";
			this->textBox13->Size = System::Drawing::Size(100, 20);
			this->textBox13->TabIndex = 24;
			this->textBox13->Visible = false;
			// 
			// textBox14
			// 
			this->textBox14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox14->Location = System::Drawing::Point(166, 569);
			this->textBox14->Name = L"textBox14";
			this->textBox14->Size = System::Drawing::Size(100, 20);
			this->textBox14->TabIndex = 29;
			this->textBox14->Visible = false;
			// 
			// textBox15
			// 
			this->textBox15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox15->Location = System::Drawing::Point(775, 488);
			this->textBox15->Name = L"textBox15";
			this->textBox15->Size = System::Drawing::Size(100, 20);
			this->textBox15->TabIndex = 28;
			this->textBox15->Visible = false;
			// 
			// textBox16
			// 
			this->textBox16->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox16->Location = System::Drawing::Point(775, 514);
			this->textBox16->Name = L"textBox16";
			this->textBox16->Size = System::Drawing::Size(100, 20);
			this->textBox16->TabIndex = 27;
			this->textBox16->Visible = false;
			// 
			// textBox17
			// 
			this->textBox17->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox17->Location = System::Drawing::Point(775, 540);
			this->textBox17->Name = L"textBox17";
			this->textBox17->Size = System::Drawing::Size(100, 20);
			this->textBox17->TabIndex = 26;
			this->textBox17->Visible = false;
			// 
			// textBox18
			// 
			this->textBox18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox18->Location = System::Drawing::Point(927, 489);
			this->textBox18->Name = L"textBox18";
			this->textBox18->Size = System::Drawing::Size(100, 20);
			this->textBox18->TabIndex = 25;
			this->textBox18->Visible = false;
			// 
			// textBox19
			// 
			this->textBox19->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox19->Location = System::Drawing::Point(927, 515);
			this->textBox19->Name = L"textBox19";
			this->textBox19->Size = System::Drawing::Size(100, 20);
			this->textBox19->TabIndex = 33;
			this->textBox19->Visible = false;
			// 
			// textBox20
			// 
			this->textBox20->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox20->Location = System::Drawing::Point(775, 566);
			this->textBox20->Name = L"textBox20";
			this->textBox20->Size = System::Drawing::Size(100, 20);
			this->textBox20->TabIndex = 32;
			this->textBox20->Visible = false;
			// 
			// textBox21
			// 
			this->textBox21->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox21->Location = System::Drawing::Point(927, 541);
			this->textBox21->Name = L"textBox21";
			this->textBox21->Size = System::Drawing::Size(100, 20);
			this->textBox21->TabIndex = 31;
			this->textBox21->Visible = false;
			// 
			// textBox22
			// 
			this->textBox22->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox22->Location = System::Drawing::Point(927, 567);
			this->textBox22->Name = L"textBox22";
			this->textBox22->Size = System::Drawing::Size(100, 20);
			this->textBox22->TabIndex = 30;
			this->textBox22->Visible = false;
			// 
			// textBox23
			// 
			this->textBox23->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox23->Location = System::Drawing::Point(927, 593);
			this->textBox23->Name = L"textBox23";
			this->textBox23->Size = System::Drawing::Size(100, 20);
			this->textBox23->TabIndex = 38;
			this->textBox23->Visible = false;
			// 
			// textBox24
			// 
			this->textBox24->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox24->Location = System::Drawing::Point(166, 595);
			this->textBox24->Name = L"textBox24";
			this->textBox24->Size = System::Drawing::Size(100, 20);
			this->textBox24->TabIndex = 37;
			this->textBox24->Visible = false;
			// 
			// textBox25
			// 
			this->textBox25->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox25->Location = System::Drawing::Point(166, 621);
			this->textBox25->Name = L"textBox25";
			this->textBox25->Size = System::Drawing::Size(100, 20);
			this->textBox25->TabIndex = 36;
			this->textBox25->Visible = false;
			// 
			// textBox26
			// 
			this->textBox26->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox26->Location = System::Drawing::Point(371, 566);
			this->textBox26->Name = L"textBox26";
			this->textBox26->Size = System::Drawing::Size(100, 20);
			this->textBox26->TabIndex = 35;
			this->textBox26->Visible = false;
			// 
			// textBox27
			// 
			this->textBox27->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox27->Location = System::Drawing::Point(371, 592);
			this->textBox27->Name = L"textBox27";
			this->textBox27->Size = System::Drawing::Size(100, 20);
			this->textBox27->TabIndex = 34;
			this->textBox27->Visible = false;
			// 
			// textBox28
			// 
			this->textBox28->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox28->Location = System::Drawing::Point(371, 618);
			this->textBox28->Name = L"textBox28";
			this->textBox28->Size = System::Drawing::Size(100, 20);
			this->textBox28->TabIndex = 41;
			this->textBox28->Visible = false;
			// 
			// textBox33
			// 
			this->textBox33->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox33->Location = System::Drawing::Point(53, 183);
			this->textBox33->Name = L"textBox33";
			this->textBox33->Size = System::Drawing::Size(100, 20);
			this->textBox33->TabIndex = 40;
			// 
			// textBox32
			// 
			this->textBox32->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox32->Location = System::Drawing::Point(53, 132);
			this->textBox32->Name = L"textBox32";
			this->textBox32->Size = System::Drawing::Size(100, 20);
			this->textBox32->TabIndex = 39;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label7->Location = System::Drawing::Point(120, 520);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(40, 13);
			this->label7->TabIndex = 43;
			this->label7->Text = L"Curso1";
			this->label7->Visible = false;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label8->Location = System::Drawing::Point(120, 547);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(40, 13);
			this->label8->TabIndex = 44;
			this->label8->Text = L"Curso2";
			this->label8->Visible = false;
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label17->Location = System::Drawing::Point(120, 573);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(40, 13);
			this->label17->TabIndex = 45;
			this->label17->Text = L"Curso3";
			this->label17->Visible = false;
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label26->Location = System::Drawing::Point(120, 599);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(40, 13);
			this->label26->TabIndex = 46;
			this->label26->Text = L"Curso4";
			this->label26->Visible = false;
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label27->Location = System::Drawing::Point(120, 625);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(40, 13);
			this->label27->TabIndex = 47;
			this->label27->Text = L"Curso5";
			this->label27->Visible = false;
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label25->Location = System::Drawing::Point(881, 599);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(40, 13);
			this->label25->TabIndex = 52;
			this->label25->Text = L"Curso5";
			this->label25->Visible = false;
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label24->Location = System::Drawing::Point(881, 573);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(40, 13);
			this->label24->TabIndex = 51;
			this->label24->Text = L"Curso4";
			this->label24->Visible = false;
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label23->Location = System::Drawing::Point(881, 547);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(40, 13);
			this->label23->TabIndex = 50;
			this->label23->Text = L"Curso3";
			this->label23->Visible = false;
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label21->Location = System::Drawing::Point(881, 521);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(40, 13);
			this->label21->TabIndex = 49;
			this->label21->Text = L"Curso2";
			this->label21->Visible = false;
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label20->Location = System::Drawing::Point(881, 494);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(40, 13);
			this->label20->TabIndex = 48;
			this->label20->Text = L"Curso1";
			this->label20->Visible = false;
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label31->Location = System::Drawing::Point(302, 625);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(63, 13);
			this->label31->TabIndex = 57;
			this->label31->Text = L"NotaCurso5";
			this->label31->Visible = false;
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label29->Location = System::Drawing::Point(302, 598);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(63, 13);
			this->label29->TabIndex = 56;
			this->label29->Text = L"NotaCurso4";
			this->label29->Visible = false;
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label28->Location = System::Drawing::Point(302, 573);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(63, 13);
			this->label28->TabIndex = 55;
			this->label28->Text = L"NotaCurso3";
			this->label28->Visible = false;
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label13->Location = System::Drawing::Point(302, 547);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(63, 13);
			this->label13->TabIndex = 54;
			this->label13->Text = L"NotaCurso2";
			this->label13->Visible = false;
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label12->Location = System::Drawing::Point(302, 517);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(63, 13);
			this->label12->TabIndex = 53;
			this->label12->Text = L"NotaCurso1";
			this->label12->Visible = false;
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label22->Location = System::Drawing::Point(706, 572);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(35, 13);
			this->label22->TabIndex = 61;
			this->label22->Text = L"Cargo";
			this->label22->Visible = false;
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label19->Location = System::Drawing::Point(695, 543);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(74, 13);
			this->label19->TabIndex = 60;
			this->label19->Text = L"Departamento";
			this->label19->Visible = false;
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label18->Location = System::Drawing::Point(670, 517);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(99, 13);
			this->label18->TabIndex = 59;
			this->label18->Text = L"A�osDeAntiguedad";
			this->label18->Visible = false;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label2->Location = System::Drawing::Point(706, 491);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(39, 13);
			this->label2->TabIndex = 58;
			this->label2->Text = L"Salario";
			this->label2->Visible = false;
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label16->Location = System::Drawing::Point(712, 389);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(44, 13);
			this->label16->TabIndex = 62;
			this->label16->Text = L"Nombre";
			this->label16->Visible = false;
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label15->Location = System::Drawing::Point(818, 393);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(49, 13);
			this->label15->TabIndex = 63;
			this->label15->Text = L"Apellidos";
			this->label15->Visible = false;
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label14->Location = System::Drawing::Point(924, 393);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(25, 13);
			this->label14->TabIndex = 64;
			this->label14->Text = L"DPI";
			this->label14->Visible = false;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label6->Location = System::Drawing::Point(375, 388);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(25, 13);
			this->label6->TabIndex = 67;
			this->label6->Text = L"DPI";
			this->label6->Visible = false;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label5->Location = System::Drawing::Point(259, 388);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(49, 13);
			this->label5->TabIndex = 66;
			this->label5->Text = L"Apellidos";
			this->label5->Visible = false;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label4->Location = System::Drawing::Point(143, 388);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(44, 13);
			this->label4->TabIndex = 65;
			this->label4->Text = L"Nombre";
			this->label4->Visible = false;
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label10->Location = System::Drawing::Point(122, 471);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(26, 13);
			this->label10->TabIndex = 68;
			this->label10->Text = L"A�o";
			this->label10->Visible = false;
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label32->Location = System::Drawing::Point(397, 471);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(48, 13);
			this->label32->TabIndex = 70;
			this->label32->Text = L"Facultad";
			this->label32->Visible = false;
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label30->Location = System::Drawing::Point(409, 5);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(25, 13);
			this->label30->TabIndex = 71;
			this->label30->Text = L"DPI";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label34->Location = System::Drawing::Point(39, 167);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(44, 13);
			this->label34->TabIndex = 72;
			this->label34->Text = L"Nombre";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label33->Location = System::Drawing::Point(36, 116);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(39, 13);
			this->label33->TabIndex = 73;
			this->label33->Text = L"Cursos";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label35->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label35->Location = System::Drawing::Point(156, 351);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(287, 24);
			this->label35->TabIndex = 253;
			this->label35->Text = L"DATOS DEL ESTUDIANTE";
			this->label35->Visible = false;
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label37->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 15.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label37->Location = System::Drawing::Point(711, 351);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(290, 24);
			this->label37->TabIndex = 254;
			this->label37->Text = L"DATOS DEL TRABAJADOR";
			this->label37->Visible = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label1->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(9, 136);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(118, 21);
			this->label1->TabIndex = 257;
			this->label1->Text = L"Estudiantes ";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label3->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(973, 136);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(123, 21);
			this->label3->TabIndex = 258;
			this->label3->Text = L"Trabajadores";
			// 
			// listNombreE
			// 
			this->listNombreE->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listNombreE->FormattingEnabled = true;
			this->listNombreE->Location = System::Drawing::Point(125, 44);
			this->listNombreE->Name = L"listNombreE";
			this->listNombreE->Size = System::Drawing::Size(249, 264);
			this->listNombreE->TabIndex = 260;
			this->listNombreE->Visible = false;
			// 
			// listApellidoE
			// 
			this->listApellidoE->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listApellidoE->FormattingEnabled = true;
			this->listApellidoE->Location = System::Drawing::Point(125, 44);
			this->listApellidoE->Name = L"listApellidoE";
			this->listApellidoE->Size = System::Drawing::Size(249, 264);
			this->listApellidoE->TabIndex = 261;
			this->listApellidoE->Visible = false;
			// 
			// listDPIE
			// 
			this->listDPIE->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listDPIE->FormattingEnabled = true;
			this->listDPIE->Location = System::Drawing::Point(125, 44);
			this->listDPIE->Name = L"listDPIE";
			this->listDPIE->Size = System::Drawing::Size(249, 264);
			this->listDPIE->TabIndex = 262;
			this->listDPIE->Visible = false;
			// 
			// listGrado
			// 
			this->listGrado->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listGrado->FormattingEnabled = true;
			this->listGrado->Location = System::Drawing::Point(125, 44);
			this->listGrado->Name = L"listGrado";
			this->listGrado->Size = System::Drawing::Size(249, 264);
			this->listGrado->TabIndex = 263;
			this->listGrado->Visible = false;
			// 
			// listCentroTrabajo
			// 
			this->listCentroTrabajo->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listCentroTrabajo->FormattingEnabled = true;
			this->listCentroTrabajo->Location = System::Drawing::Point(125, 44);
			this->listCentroTrabajo->Name = L"listCentroTrabajo";
			this->listCentroTrabajo->Size = System::Drawing::Size(249, 264);
			this->listCentroTrabajo->TabIndex = 264;
			this->listCentroTrabajo->Visible = false;
			// 
			// listEstudio
			// 
			this->listEstudio->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listEstudio->FormattingEnabled = true;
			this->listEstudio->Location = System::Drawing::Point(125, 44);
			this->listEstudio->Name = L"listEstudio";
			this->listEstudio->Size = System::Drawing::Size(249, 264);
			this->listEstudio->TabIndex = 265;
			this->listEstudio->Visible = false;
			// 
			// listCarrera
			// 
			this->listCarrera->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listCarrera->FormattingEnabled = true;
			this->listCarrera->Location = System::Drawing::Point(125, 44);
			this->listCarrera->Name = L"listCarrera";
			this->listCarrera->Size = System::Drawing::Size(249, 264);
			this->listCarrera->TabIndex = 266;
			this->listCarrera->Visible = false;
			// 
			// listAnio
			// 
			this->listAnio->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listAnio->FormattingEnabled = true;
			this->listAnio->Location = System::Drawing::Point(125, 44);
			this->listAnio->Name = L"listAnio";
			this->listAnio->Size = System::Drawing::Size(249, 264);
			this->listAnio->TabIndex = 267;
			this->listAnio->Visible = false;
			// 
			// listC1E
			// 
			this->listC1E->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listC1E->FormattingEnabled = true;
			this->listC1E->Location = System::Drawing::Point(125, 44);
			this->listC1E->Name = L"listC1E";
			this->listC1E->Size = System::Drawing::Size(249, 264);
			this->listC1E->TabIndex = 268;
			this->listC1E->Visible = false;
			// 
			// listC2E
			// 
			this->listC2E->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listC2E->FormattingEnabled = true;
			this->listC2E->Location = System::Drawing::Point(125, 44);
			this->listC2E->Name = L"listC2E";
			this->listC2E->Size = System::Drawing::Size(249, 264);
			this->listC2E->TabIndex = 269;
			this->listC2E->Visible = false;
			// 
			// listNC1E
			// 
			this->listNC1E->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listNC1E->FormattingEnabled = true;
			this->listNC1E->Location = System::Drawing::Point(125, 44);
			this->listNC1E->Name = L"listNC1E";
			this->listNC1E->Size = System::Drawing::Size(249, 264);
			this->listNC1E->TabIndex = 270;
			this->listNC1E->Visible = false;
			// 
			// listNC2E
			// 
			this->listNC2E->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listNC2E->FormattingEnabled = true;
			this->listNC2E->Location = System::Drawing::Point(125, 44);
			this->listNC2E->Name = L"listNC2E";
			this->listNC2E->Size = System::Drawing::Size(249, 264);
			this->listNC2E->TabIndex = 271;
			this->listNC2E->Visible = false;
			// 
			// listPromE
			// 
			this->listPromE->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listPromE->FormattingEnabled = true;
			this->listPromE->Location = System::Drawing::Point(125, 44);
			this->listPromE->Name = L"listPromE";
			this->listPromE->Size = System::Drawing::Size(249, 264);
			this->listPromE->TabIndex = 272;
			// 
			// listC4
			// 
			this->listC4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listC4->FormattingEnabled = true;
			this->listC4->Location = System::Drawing::Point(125, 44);
			this->listC4->Name = L"listC4";
			this->listC4->Size = System::Drawing::Size(249, 264);
			this->listC4->TabIndex = 273;
			// 
			// listBoxC3
			// 
			this->listBoxC3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBoxC3->FormattingEnabled = true;
			this->listBoxC3->Location = System::Drawing::Point(125, 44);
			this->listBoxC3->Name = L"listBoxC3";
			this->listBoxC3->Size = System::Drawing::Size(249, 264);
			this->listBoxC3->TabIndex = 274;
			// 
			// listC5
			// 
			this->listC5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listC5->FormattingEnabled = true;
			this->listC5->Location = System::Drawing::Point(125, 42);
			this->listC5->Name = L"listC5";
			this->listC5->Size = System::Drawing::Size(249, 264);
			this->listC5->TabIndex = 275;
			// 
			// listNC3
			// 
			this->listNC3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listNC3->FormattingEnabled = true;
			this->listNC3->Location = System::Drawing::Point(125, 42);
			this->listNC3->Name = L"listNC3";
			this->listNC3->Size = System::Drawing::Size(249, 264);
			this->listNC3->TabIndex = 276;
			// 
			// listNC4
			// 
			this->listNC4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listNC4->FormattingEnabled = true;
			this->listNC4->Location = System::Drawing::Point(125, 44);
			this->listNC4->Name = L"listNC4";
			this->listNC4->Size = System::Drawing::Size(249, 264);
			this->listNC4->TabIndex = 277;
			// 
			// listNC5
			// 
			this->listNC5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listNC5->FormattingEnabled = true;
			this->listNC5->Location = System::Drawing::Point(125, 42);
			this->listNC5->Name = L"listNC5";
			this->listNC5->Size = System::Drawing::Size(249, 264);
			this->listNC5->TabIndex = 278;
			// 
			// listfacultad
			// 
			this->listfacultad->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listfacultad->FormattingEnabled = true;
			this->listfacultad->Location = System::Drawing::Point(125, 42);
			this->listfacultad->Name = L"listfacultad";
			this->listfacultad->Size = System::Drawing::Size(249, 264);
			this->listfacultad->TabIndex = 279;
			// 
			// listMuestraVF
			// 
			this->listMuestraVF->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listMuestraVF->FormattingEnabled = true;
			this->listMuestraVF->Location = System::Drawing::Point(125, 44);
			this->listMuestraVF->Name = L"listMuestraVF";
			this->listMuestraVF->Size = System::Drawing::Size(249, 264);
			this->listMuestraVF->TabIndex = 280;
			this->listMuestraVF->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::listMuestraVF_SelectedIndexChanged);
			// 
			// listBox1
			// 
			this->listBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox1->FormattingEnabled = true;
			this->listBox1->Location = System::Drawing::Point(722, 42);
			this->listBox1->Name = L"listBox1";
			this->listBox1->Size = System::Drawing::Size(245, 264);
			this->listBox1->TabIndex = 281;
			// 
			// listBox2
			// 
			this->listBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox2->FormattingEnabled = true;
			this->listBox2->Location = System::Drawing::Point(722, 42);
			this->listBox2->Name = L"listBox2";
			this->listBox2->Size = System::Drawing::Size(245, 264);
			this->listBox2->TabIndex = 282;
			// 
			// listBox3
			// 
			this->listBox3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox3->FormattingEnabled = true;
			this->listBox3->Location = System::Drawing::Point(722, 42);
			this->listBox3->Name = L"listBox3";
			this->listBox3->Size = System::Drawing::Size(245, 264);
			this->listBox3->TabIndex = 283;
			// 
			// listBox4
			// 
			this->listBox4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox4->FormattingEnabled = true;
			this->listBox4->Location = System::Drawing::Point(715, 42);
			this->listBox4->Name = L"listBox4";
			this->listBox4->Size = System::Drawing::Size(245, 264);
			this->listBox4->TabIndex = 284;
			// 
			// listBox5
			// 
			this->listBox5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox5->FormattingEnabled = true;
			this->listBox5->Location = System::Drawing::Point(715, 42);
			this->listBox5->Name = L"listBox5";
			this->listBox5->Size = System::Drawing::Size(245, 264);
			this->listBox5->TabIndex = 285;
			// 
			// listBox6
			// 
			this->listBox6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox6->FormattingEnabled = true;
			this->listBox6->Location = System::Drawing::Point(715, 42);
			this->listBox6->Name = L"listBox6";
			this->listBox6->Size = System::Drawing::Size(245, 264);
			this->listBox6->TabIndex = 286;
			// 
			// listBox7
			// 
			this->listBox7->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox7->FormattingEnabled = true;
			this->listBox7->Location = System::Drawing::Point(715, 42);
			this->listBox7->Name = L"listBox7";
			this->listBox7->Size = System::Drawing::Size(245, 264);
			this->listBox7->TabIndex = 287;
			// 
			// listBox8
			// 
			this->listBox8->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox8->FormattingEnabled = true;
			this->listBox8->Location = System::Drawing::Point(715, 42);
			this->listBox8->Name = L"listBox8";
			this->listBox8->Size = System::Drawing::Size(245, 264);
			this->listBox8->TabIndex = 288;
			// 
			// listBox9
			// 
			this->listBox9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox9->FormattingEnabled = true;
			this->listBox9->Location = System::Drawing::Point(715, 42);
			this->listBox9->Name = L"listBox9";
			this->listBox9->Size = System::Drawing::Size(245, 264);
			this->listBox9->TabIndex = 289;
			// 
			// listBox10
			// 
			this->listBox10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox10->FormattingEnabled = true;
			this->listBox10->Location = System::Drawing::Point(715, 42);
			this->listBox10->Name = L"listBox10";
			this->listBox10->Size = System::Drawing::Size(245, 264);
			this->listBox10->TabIndex = 290;
			// 
			// listBox11
			// 
			this->listBox11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox11->FormattingEnabled = true;
			this->listBox11->Location = System::Drawing::Point(715, 42);
			this->listBox11->Name = L"listBox11";
			this->listBox11->Size = System::Drawing::Size(245, 264);
			this->listBox11->TabIndex = 291;
			// 
			// listBox12
			// 
			this->listBox12->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox12->FormattingEnabled = true;
			this->listBox12->Location = System::Drawing::Point(715, 42);
			this->listBox12->Name = L"listBox12";
			this->listBox12->Size = System::Drawing::Size(245, 264);
			this->listBox12->TabIndex = 292;
			// 
			// listBox13
			// 
			this->listBox13->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox13->FormattingEnabled = true;
			this->listBox13->Location = System::Drawing::Point(715, 42);
			this->listBox13->Name = L"listBox13";
			this->listBox13->Size = System::Drawing::Size(245, 264);
			this->listBox13->TabIndex = 293;
			// 
			// listBox14
			// 
			this->listBox14->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->listBox14->FormattingEnabled = true;
			this->listBox14->Location = System::Drawing::Point(715, 42);
			this->listBox14->Name = L"listBox14";
			this->listBox14->Size = System::Drawing::Size(245, 264);
			this->listBox14->TabIndex = 294;
			// 
			// textBox31
			// 
			this->textBox31->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox31->Location = System::Drawing::Point(715, 44);
			this->textBox31->Multiline = true;
			this->textBox31->Name = L"textBox31";
			this->textBox31->Size = System::Drawing::Size(252, 264);
			this->textBox31->TabIndex = 295;
			this->textBox31->Visible = false;
			// 
			// textBox6
			// 
			this->textBox6->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox6->Location = System::Drawing::Point(113, 488);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(133, 20);
			this->textBox6->TabIndex = 296;
			this->textBox6->Visible = false;
			// 
			// comboBox3
			// 
			this->comboBox3->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Diplomado", L"Maestria", L"Doctorado" });
			this->comboBox3->Location = System::Drawing::Point(115, 487);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(131, 21);
			this->comboBox3->TabIndex = 297;
			this->comboBox3->Text = L"Tipo de Estudio";
			this->comboBox3->Visible = false;
			this->comboBox3->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox3_SelectedIndexChanged);
			// 
			// textBox4
			// 
			this->textBox4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox4->Location = System::Drawing::Point(250, 489);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(133, 20);
			this->textBox4->TabIndex = 298;
			this->textBox4->Visible = false;
			// 
			// textBox5
			// 
			this->textBox5->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox5->Location = System::Drawing::Point(250, 488);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(133, 20);
			this->textBox5->TabIndex = 299;
			this->textBox5->Visible = false;
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label11->Location = System::Drawing::Point(252, 473);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(41, 13);
			this->label11->TabIndex = 300;
			this->label11->Text = L"Carrera";
			this->label11->Visible = false;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->label9->Location = System::Drawing::Point(252, 472);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(88, 13);
			this->label9->TabIndex = 301;
			this->label9->Text = L"Centro de trabajo";
			this->label9->Visible = false;
			// 
			// button7
			// 
			this->button7->BackColor = System::Drawing::Color::MediumPurple;
			this->button7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button7->Location = System::Drawing::Point(100, 84);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(100, 33);
			this->button7->TabIndex = 302;
			this->button7->Text = L"Est.Maestria";
			this->button7->UseVisualStyleBackColor = false;
			// 
			// textBox10
			// 
			this->textBox10->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->textBox10->Location = System::Drawing::Point(371, 540);
			this->textBox10->Name = L"textBox10";
			this->textBox10->Size = System::Drawing::Size(100, 20);
			this->textBox10->TabIndex = 303;
			this->textBox10->Visible = false;
			// 
			// comboBox1
			// 
			this->comboBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Estudiante", L"Trabajador" });
			this->comboBox1->Location = System::Drawing::Point(456, 310);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(183, 21);
			this->comboBox1->TabIndex = 304;
			this->comboBox1->Text = L"Tipo de Personal";
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox1_SelectedIndexChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Pre-Grado", L"Post-Grado" });
			this->comboBox2->Location = System::Drawing::Point(250, 430);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(131, 21);
			this->comboBox2->TabIndex = 305;
			this->comboBox2->Text = L"Grado";
			this->comboBox2->Visible = false;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox2_SelectedIndexChanged);
			// 
			// groupBox1
			// 
			this->groupBox1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->groupBox1->Controls->Add(this->button4);
			this->groupBox1->Controls->Add(this->button3);
			this->groupBox1->Controls->Add(this->button8);
			this->groupBox1->Controls->Add(this->button9);
			this->groupBox1->Controls->Add(this->button7);
			this->groupBox1->Controls->Add(this->textBox32);
			this->groupBox1->Controls->Add(this->textBox33);
			this->groupBox1->Controls->Add(this->label34);
			this->groupBox1->Controls->Add(this->label33);
			this->groupBox1->Location = System::Drawing::Point(387, 67);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(317, 214);
			this->groupBox1->TabIndex = 306;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"groupBox1";
			this->groupBox1->Visible = false;
			// 
			// groupBox2
			// 
			this->groupBox2->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->groupBox2->Controls->Add(this->button6);
			this->groupBox2->Controls->Add(this->button2);
			this->groupBox2->Controls->Add(this->button5);
			this->groupBox2->Location = System::Drawing::Point(487, 598);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(269, 58);
			this->groupBox2->TabIndex = 307;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"groupBox2";
			this->groupBox2->Visible = false;
			// 
			// comboBox4
			// 
			this->comboBox4->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Docente", L"Empleado" });
			this->comboBox4->Location = System::Drawing::Point(806, 448);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(131, 21);
			this->comboBox4->TabIndex = 309;
			this->comboBox4->Text = L"Puesto";
			this->comboBox4->Visible = false;
			this->comboBox4->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::comboBox4_SelectedIndexChanged);
			// 
			// button10
			// 
			this->button10->BackColor = System::Drawing::Color::MediumPurple;
			this->button10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button10->Location = System::Drawing::Point(564, 428);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(75, 23);
			this->button10->TabIndex = 6;
			this->button10->Text = L"Menu";
			this->button10->UseVisualStyleBackColor = false;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm::button10_Click_1);
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->BackColor = System::Drawing::Color::Purple;
			this->label36->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label36->ForeColor = System::Drawing::Color::White;
			this->label36->Location = System::Drawing::Point(12, 9);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(145, 20);
			this->label36->TabIndex = 310;
			this->label36->Text = L"PERSONAL URL";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::MediumPurple;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(1105, 669);
			this->Controls->Add(this->label36);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->comboBox4);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->textBox10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->textBox5);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->comboBox3);
			this->Controls->Add(this->textBox6);
			this->Controls->Add(this->textBox31);
			this->Controls->Add(this->listBox14);
			this->Controls->Add(this->listBox13);
			this->Controls->Add(this->listBox12);
			this->Controls->Add(this->listBox11);
			this->Controls->Add(this->listBox10);
			this->Controls->Add(this->listBox9);
			this->Controls->Add(this->listBox8);
			this->Controls->Add(this->listBox7);
			this->Controls->Add(this->listBox6);
			this->Controls->Add(this->listBox5);
			this->Controls->Add(this->listBox4);
			this->Controls->Add(this->listBox3);
			this->Controls->Add(this->listBox2);
			this->Controls->Add(this->listBox1);
			this->Controls->Add(this->listMuestraVF);
			this->Controls->Add(this->listfacultad);
			this->Controls->Add(this->listNC5);
			this->Controls->Add(this->listNC4);
			this->Controls->Add(this->listNC3);
			this->Controls->Add(this->listC5);
			this->Controls->Add(this->listBoxC3);
			this->Controls->Add(this->listC4);
			this->Controls->Add(this->listPromE);
			this->Controls->Add(this->listNC2E);
			this->Controls->Add(this->listNC1E);
			this->Controls->Add(this->listC2E);
			this->Controls->Add(this->listC1E);
			this->Controls->Add(this->listAnio);
			this->Controls->Add(this->listCarrera);
			this->Controls->Add(this->listEstudio);
			this->Controls->Add(this->listCentroTrabajo);
			this->Controls->Add(this->listGrado);
			this->Controls->Add(this->listDPIE);
			this->Controls->Add(this->listApellidoE);
			this->Controls->Add(this->listNombreE);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label37);
			this->Controls->Add(this->label35);
			this->Controls->Add(this->label30);
			this->Controls->Add(this->label32);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label15);
			this->Controls->Add(this->label16);
			this->Controls->Add(this->label22);
			this->Controls->Add(this->label19);
			this->Controls->Add(this->label18);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label31);
			this->Controls->Add(this->label29);
			this->Controls->Add(this->label28);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label25);
			this->Controls->Add(this->label24);
			this->Controls->Add(this->label23);
			this->Controls->Add(this->label21);
			this->Controls->Add(this->label20);
			this->Controls->Add(this->label27);
			this->Controls->Add(this->label26);
			this->Controls->Add(this->label17);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->textBox28);
			this->Controls->Add(this->textBox23);
			this->Controls->Add(this->textBox24);
			this->Controls->Add(this->textBox25);
			this->Controls->Add(this->textBox26);
			this->Controls->Add(this->textBox27);
			this->Controls->Add(this->textBox19);
			this->Controls->Add(this->textBox20);
			this->Controls->Add(this->textBox21);
			this->Controls->Add(this->textBox22);
			this->Controls->Add(this->textBox14);
			this->Controls->Add(this->textBox15);
			this->Controls->Add(this->textBox16);
			this->Controls->Add(this->textBox17);
			this->Controls->Add(this->textBox18);
			this->Controls->Add(this->textBox13);
			this->Controls->Add(this->textBox12);
			this->Controls->Add(this->textBox11);
			this->Controls->Add(this->textBox9);
			this->Controls->Add(this->textBox8);
			this->Controls->Add(this->textBox7);
			this->Controls->Add(this->textBox30);
			this->Controls->Add(this->textBox29);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
		void MarshalString(String^ s, string& os) {
			using namespace Runtime::InteropServices;
			const char* chars =
				(const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
			os = chars;
			Marshal::FreeHGlobal(IntPtr((void*)chars));
		}

#pragma endregion
private: System::Void MyForm_Load(System::Object^ sender, System::EventArgs^ e) {
	listNombreE->Items->Add("Jose");
	listApellidoE->Items->Add("Recinos Martinez");
	listGrado->Items->Add("Pre-Grado");
	listDPIE->Items->Add(2145541);
	listCarrera->Items->Add("Informatica y Sistemas");
	listAnio->Items->Add(1);
	listC4->Items->Add("Programacion Avanzada");
	listC1E->Items->Add("Calculo I");
	listC2E->Items->Add("Magis Landivariano");
	listBoxC3->Items->Add("Fisica I");
	listC5->Items->Add("Matematica Discreta II");
	listNC1E->Items->Add(70);
	listNC2E->Items->Add(98);
	listNC3->Items->Add(65.5);
	listNC4->Items->Add(72.3);
	listNC5->Items->Add(65);
	listCentroTrabajo->Items->Add("No Aplica");
	listEstudio->Items->Add("No Aplica");
	listPromE->Items->Add(73.56);
	listfacultad->Items->Add("Ingenieria");
	listMuestraVF->Items->Add("Jose - Recinos Martinez - 2145541 - Pre-Grado");



	listBox1->Items->Add("Luis");
	listBox2->Items->Add("Rivera Jacome");
	listBox3->Items->Add(5587745);
	listBox4->Items->Add("Empleado");
	listBox5->Items->Add(5550.00);
	listBox6->Items->Add(1);
	listBox7->Items->Add("Parqueo");
	listBox8->Items->Add("No aplica");
	listBox9->Items->Add("No aplica");
	listBox10->Items->Add("No aplica");
	listBox11->Items->Add("No aplica");
	listBox12->Items->Add("No aplica");
	listBox13->Items->Add("Gerente");
	listBox14->Items->Add("Luis - Rivera Jacome - 5587745 - Empleado");

}
private: System::Void button5_Click(System::Object^ sender, System::EventArgs^ e) {
	int tamanio = listDPIE->Items->Count;
	int tamaniotrabajador = listBox3->Items->Count;
	if (comboBox1->Text == "Estudiante")
	{
		int conprom = 0;
		String^ nombre;
		String^ Apellido;
		int DPI;
		String^ grado;
		String^ carrera;
		int anio;
		String^ curso1;
		String^ curso2;
		String^ curso3;
		String^ curso4;
		String^ curso5;
		String^ facultad;
		double notac1;
		double notac2;
		double notac3;
		double notac4;
		double notac5;
		String^ CTrabajo;
		String^ TEstudio;
		double prom;

		if (comboBox2->Text == "Pre-Grado")
		{
			anio = Convert::ToUInt32(textBox6->Text);
			if (textBox9->Text == "")
			{
				notac1 = 0;
			}
			else
			{
				notac1 = Convert::ToDouble(textBox9->Text);
				conprom++;
			}

			if (textBox10->Text == "")
			{
				notac2 = 0;
			}
			else
			{
				notac2 = Convert::ToDouble(textBox10->Text);
				conprom++;
			}

			if (textBox26->Text == "")
			{
				notac3 = 0;
			}
			else
			{
				notac3 = Convert::ToDouble(textBox26->Text);
				conprom++;
			}

			if (textBox27->Text == "")
			{
				notac4 = 0;
			}
			else
			{
				notac4 = Convert::ToDouble(textBox27->Text);
				conprom++;
			}

			if (textBox28->Text == "")
			{
				notac5 = 0;
			}
			else
			{
				notac5 = Convert::ToDouble(textBox28->Text);
				conprom++;
			}
			nombre = textBox1->Text;
			Apellido = textBox2->Text;
			DPI = Convert::ToInt32(textBox3->Text);
			grado = comboBox2->Text;
			carrera = textBox5->Text;
			curso1 = textBox7->Text;

			if (facultad == "")
			{
				facultad = "Desconocida";
			}
			else
			{
				facultad = textBox29->Text;
			}
			if (textBox7->Text == "")
			{
				curso1 = "No Asignado";
			}
			else
			{
				curso1 = textBox7->Text;
			}
			if (textBox8->Text == "")
			{
				curso2 = "No Asignado";
			}
			else
			{
				curso2 = textBox8->Text;
			}

			if (textBox14->Text == "")
			{
				curso3 = "No Asignado";
			}
			else
			{
				curso3 = textBox14->Text;
			}

			if (textBox24->Text == "")
			{
				curso4 = "No Asignado";
			}
			else
			{
				curso4 = textBox24->Text;
			}

			if (textBox25->Text == "")
			{
				curso5 = "No Asignado";
			}
			else {
				curso5 = textBox25->Text;
			}
			prom = (notac1 + notac2 + notac3 + notac4 + notac5) / conprom;
			CTrabajo = "No aplica";
			TEstudio = "No aplica";

		}
		else if (comboBox2->Text == "Pos-Grado")
		{

			nombre = textBox1->Text;
			Apellido = textBox2->Text;
			DPI = Convert::ToInt32(textBox3->Text);
			grado = comboBox2->Text;
			CTrabajo = textBox4->Text;
			TEstudio = comboBox3->Text;
			carrera = "No aplica";
			anio = 0;

			if (textBox7->Text == "")
			{
				curso1 = "No Asignado";
			}
			else
			{
				curso1 = textBox7->Text;

			}

			if (textBox8->Text == "")
			{
				curso2 = "No Asignado";
			}
			else
			{
				curso2 = textBox8->Text;

			}

			if (textBox14->Text == "")
			{
				curso3 = "No Asignado";
			}
			else
			{
				curso3 = textBox14->Text;

			}

			if (textBox24->Text == "")
			{
				curso4 = "No Asignado";
			}
			else
			{
				curso4 = textBox24->Text;

			}

			if (textBox25->Text == "")
			{
				curso5 = "No Asignado";
			}
			else
			{
				curso5 = textBox25->Text;
			}

			if (textBox9->Text == "")
			{
				notac1 = 0;
			}
			else
			{
				notac1 = Convert::ToDouble(textBox9->Text);
				conprom++;
			}

			if (textBox10->Text == "")
			{
				notac2 = 0;
			}
			else
			{
				notac2 = Convert::ToDouble(textBox10->Text);
				conprom++;
			}

			if (textBox26->Text == "")
			{
				notac3 = 0;
			}
			else
			{
				notac3 = Convert::ToDouble(textBox26->Text);
				conprom++;
			}

			if (textBox27->Text == "")
			{
				notac4 = 0;
			}
			else
			{
				notac4 = Convert::ToDouble(textBox27->Text);
				conprom++;
			}

			if (textBox28->Text == "")
			{
				notac5 = 0;
			}
			else
			{
				notac5 = Convert::ToDouble(textBox28->Text);
				conprom++;
			}
			prom = (notac1 + notac2 + notac3 + notac4 + notac5) / conprom;
			facultad = textBox29->Text;
			if (facultad == "")
			{
				facultad = "Desconocida";
			}
		}
		for (int i = 0; i < tamanio; i++)
		{
			int compa = Convert::ToInt32(listDPIE->Items[i]);
			if (DPI == compa)
			{
				MessageBox::Show("El DPI: " + DPI + " ya esta registrado");
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox4->Text = "";
				textBox5->Text = "";
				textBox6->Text = "";
				textBox7->Text = "";
				textBox8->Text = "";
				textBox9->Text = "";
				textBox10->Text = "";
				textBox11->Text = "";
				textBox12->Text = "";
				textBox13->Text = "";
				textBox14->Text = "";
				textBox15->Text = "";
				textBox16->Text = "";
				textBox17->Text = "";
				textBox18->Text = "";
				textBox19->Text = "";
				textBox20->Text = "";
				textBox21->Text = "";
				textBox22->Text = "";
				textBox23->Text = "";
				textBox24->Text = "";
				textBox25->Text = "";
				textBox26->Text = "";
				textBox27->Text = "";
				textBox28->Text = "";
				textBox29->Text = "";
			}

		}
		for (int i = 0; i < tamaniotrabajador; i++)
		{
			int compa2 = Convert::ToInt32(listBox3->Items[i]);
			if (DPI == compa2)
			{
				MessageBox::Show("El DPI: " + DPI + " ya esta registrado");
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox4->Text = "";
				textBox5->Text = "";
				textBox6->Text = "";
				textBox7->Text = "";
				textBox8->Text = "";
				textBox9->Text = "";
				textBox10->Text = "";
				textBox11->Text = "";
				textBox12->Text = "";
				textBox13->Text = "";
				textBox14->Text = "";
				textBox15->Text = "";
				textBox16->Text = "";
				textBox17->Text = "";
				textBox18->Text = "";
				textBox19->Text = "";
				textBox20->Text = "";
				textBox21->Text = "";
				textBox22->Text = "";
				textBox23->Text = "";
				textBox24->Text = "";
				textBox25->Text = "";
				textBox26->Text = "";
				textBox27->Text = "";
				textBox28->Text = "";
				textBox29->Text = "";
			}

		}
		if (textBox1->Text != "")
		{
			String^ Muestra = nombre + " - " + Apellido + " - " + DPI + " - " + grado;
			listNombreE->Items->Add(nombre);
			listApellidoE->Items->Add(Apellido);
			listDPIE->Items->Add(DPI);
			listGrado->Items->Add(grado);
			listCarrera->Items->Add(carrera);
			listAnio->Items->Add(anio);
			listC1E->Items->Add(curso1);
			listC2E->Items->Add(curso2);
			listBoxC3->Items->Add(curso3);
			listC4->Items->Add(curso4);
			listC5->Items->Add(curso5);
			listNC1E->Items->Add(notac1);
			listNC2E->Items->Add(notac2);
			listNC3->Items->Add(notac3);
			listNC4->Items->Add(notac4);
			listNC5->Items->Add(notac5);
			listCentroTrabajo->Items->Add(CTrabajo);
			listEstudio->Items->Add(TEstudio);
			listPromE->Items->Add(prom);
			listfacultad->Items->Add(facultad);
			listMuestraVF->Items->Add(Muestra);

		}
		textBox1->Text = "";
		textBox2->Text = "";
		textBox3->Text = "";
		textBox1->Text = "";
		textBox2->Text = "";
		textBox3->Text = "";
		textBox4->Text = "";
		textBox5->Text = "";
		textBox6->Text = "";
		textBox7->Text = "";
		textBox8->Text = "";
		textBox9->Text = "";
		textBox10->Text = "";
		textBox11->Text = "";
		textBox12->Text = "";
		textBox13->Text = "";
		textBox14->Text = "";
		textBox15->Text = "";
		textBox16->Text = "";
		textBox17->Text = "";
		textBox18->Text = "";
		textBox19->Text = "";
		textBox20->Text = "";
		textBox21->Text = "";
		textBox22->Text = "";
		textBox23->Text = "";
		textBox24->Text = "";
		textBox25->Text = "";
		textBox26->Text = "";
		textBox27->Text = "";

		textBox28->Text = "";
		textBox29->Text = "";
		textBox14->Visible = false;
		label9->Visible = false;
		textBox4->Visible = false;
		comboBox3->Visible = false;
		label11->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		label11->Visible = false;
		label12->Visible = false;
		label13->Visible = false;
		label7->Visible = false;
		label10->Visible = false;
		label8->Visible = false;
		label12->Visible = false;
		textBox5->Visible = false;
		textBox6->Visible = false;
		textBox7->Visible = false;
		textBox8->Visible = false;
		textBox9->Visible = false;
		textBox10->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		textBox1->Visible = false;
		textBox2->Visible = false;
		textBox3->Visible = false;
		label4->Visible = false;
		label5->Visible = false;
		label6->Visible = false;
		comboBox2->Visible = false;

		label32->Visible = false;
		textBox29->Visible = false;
		textBox14->Visible = false;
		textBox24->Visible = false;
		textBox25->Visible = false;
		label17->Visible = false;
		label27->Visible = false;
		label26->Visible = false;
		label28->Visible = false;
		label29->Visible = false;
		label31->Visible = false;
		textBox26->Visible = false;
		textBox27->Visible = false;
		textBox28->Visible = false;
		label37->Visible = false;
		label35->Visible = false;




	}
	else if (comboBox1->Text == "Trabajador")
	{
		String^ nombret;
		String^ apellidot;
		int dpit;
		String^ puesto;
		double salario;
		int antiguo;
		String^ departamento;
		String^ Curso1;
		String^ Curso2;
		String^ Curso3;
		String^ Curso4;
		String^ Curso5;
		String^ Cargo;
		if (comboBox4->Text == "Docente")
		{
			nombret = textBox11->Text;
			apellidot = textBox12->Text;
			dpit = Convert::ToInt32(textBox13->Text);
			puesto = comboBox4->Text;
			salario = Convert::ToDouble(textBox15->Text);
			antiguo = Convert::ToInt32(textBox16->Text);
			departamento = textBox17->Text;
			if (textBox18->Text == "")
			{
				Curso1 = "No Asignado";
			}
			else
			{
				Curso1 = textBox18->Text;
			}

			if (textBox19->Text == "")
			{
				Curso2 = "No Asignado";
			}
			else
			{
				Curso2 = textBox19->Text;
			}

			if (textBox21->Text == "")
			{
				Curso3 = "No Asignado";
			}
			else
			{
				Curso3 = textBox21->Text;
			}

			if (textBox22->Text == "")
			{
				Curso4 = "No Asignado";
			}
			else
			{
				Curso4 = textBox22->Text;
			}

			if (textBox23->Text == "")
			{
				Curso5 = "No Asignado";
			}
			else
			{
				Curso5 = textBox23->Text;
			}
			Cargo = "Docente";
		}
		else if (comboBox4->Text == "Empleado")
		{

			nombret = textBox11->Text;
			apellidot = textBox12->Text;
			dpit = Convert::ToInt32(textBox13->Text);
			puesto = comboBox4->Text;
			salario = Convert::ToDouble(textBox15->Text);
			antiguo = Convert::ToInt32(textBox16->Text);
			departamento = textBox17->Text;
			Cargo = textBox20->Text;
			Curso1 = "No Aplica";
			Curso2 = "No Aplica";
			Curso3 = "No Aplica";
			Curso4 = "No Aplica";
			Curso5 = "No Aplica";

		}
		for (int i = 0; i < tamanio; i++)
		{
			int compa = Convert::ToInt32(listDPIE->Items[i]);
			if (dpit == compa)
			{
				MessageBox::Show("El DPI: " + dpit + " ya existe");
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox4->Text = "";
				textBox5->Text = "";
				textBox6->Text = "";
				textBox7->Text = "";
				textBox8->Text = "";
				textBox9->Text = "";
				textBox10->Text = "";
				textBox11->Text = "";
				textBox12->Text = "";
				textBox13->Text = "";
				textBox14->Text = "";
				textBox15->Text = "";
				textBox16->Text = "";
				textBox17->Text = "";
				textBox18->Text = "";
				textBox19->Text = "";
				textBox20->Text = "";
				textBox21->Text = "";
				textBox22->Text = "";
				textBox23->Text = "";
				textBox24->Text = "";
				textBox25->Text = "";
				textBox26->Text = "";
				textBox27->Text = "";
				textBox28->Text = "";
				textBox29->Text = "";
			}

		}
		for (int i = 0; i < tamaniotrabajador; i++)
		{
			int compa2 = Convert::ToInt32(listBox3->Items[i]);
			if (dpit == compa2)
			{
				MessageBox::Show("El DPI: " + dpit + " ya esta registrado");
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox1->Text = "";
				textBox2->Text = "";
				textBox3->Text = "";
				textBox4->Text = "";
				textBox5->Text = "";
				textBox6->Text = "";
				textBox7->Text = "";
				textBox8->Text = "";
				textBox9->Text = "";
				textBox10->Text = "";
				textBox11->Text = "";
				textBox12->Text = "";
				textBox13->Text = "";
				textBox14->Text = "";
				textBox15->Text = "";
				textBox16->Text = "";
				textBox17->Text = "";
				textBox18->Text = "";
				textBox19->Text = "";
				textBox20->Text = "";
				textBox21->Text = "";
				textBox22->Text = "";
				textBox23->Text = "";
				textBox24->Text = "";
				textBox25->Text = "";
				textBox26->Text = "";
				textBox27->Text = "";
				textBox28->Text = "";
				textBox29->Text = "";
			}

		}

		if (textBox11->Text != "")
		{
			String^ Muestra = nombret + " - " + apellidot + " - " + dpit + " - " + puesto;
			listBox1->Items->Add(nombret);
			listBox2->Items->Add(apellidot);
			listBox3->Items->Add(dpit);
			listBox4->Items->Add(puesto);
			listBox5->Items->Add(salario);
			listBox6->Items->Add(antiguo);
			listBox7->Items->Add(departamento);
			listBox8->Items->Add(Curso1);
			listBox9->Items->Add(Curso2);
			listBox10->Items->Add(Curso3);
			listBox11->Items->Add(Curso4);
			listBox12->Items->Add(Curso5);
			listBox13->Items->Add(Cargo);
			listBox14->Items->Add(Muestra);
		}
		textBox1->Text = "";
		textBox2->Text = "";
		textBox3->Text = "";
		textBox1->Text = "";
		textBox2->Text = "";
		textBox3->Text = "";
		textBox4->Text = "";
		textBox5->Text = "";
		textBox6->Text = "";
		textBox7->Text = "";
		textBox8->Text = "";
		textBox9->Text = "";
		textBox10->Text = "";
		textBox11->Text = "";
		textBox12->Text = "";
		textBox13->Text = "";
		textBox14->Text = "";
		textBox15->Text = "";
		textBox16->Text = "";
		textBox17->Text = "";
		textBox18->Text = "";
		textBox19->Text = "";
		textBox20->Text = "";
		textBox21->Text = "";
		textBox22->Text = "";
		textBox23->Text = "";
		textBox24->Text = "";
		textBox25->Text = "";
		textBox26->Text = "";
		textBox27->Text = "";

		textBox28->Text = "";
		textBox29->Text = "";
		textBox14->Visible = false;
		label9->Visible = false;
		textBox4->Visible = false;
		comboBox3->Visible = false;
		label11->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		label11->Visible = false;
		label12->Visible = false;
		label13->Visible = false;
		label7->Visible = false;
		label10->Visible = false;
		label8->Visible = false;
		label12->Visible = false;
		textBox5->Visible = false;
		textBox6->Visible = false;
		textBox7->Visible = false;
		textBox8->Visible = false;
		textBox9->Visible = false;
		textBox10->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		textBox1->Visible = false;
		textBox2->Visible = false;
		textBox3->Visible = false;
		label4->Visible = false;
		label5->Visible = false;
		label6->Visible = false;
		comboBox2->Visible = false;

		label32->Visible = false;
		textBox29->Visible = false;
		textBox14->Visible = false;
		textBox24->Visible = false;
		textBox25->Visible = false;
		label17->Visible = false;
		label27->Visible = false;
		label26->Visible = false;
		label28->Visible = false;
		label29->Visible = false;
		label31->Visible = false;
		textBox26->Visible = false;
		textBox27->Visible = false;
		textBox28->Visible = false;

		textBox15->Visible = false;
		textBox16->Visible = false;
		textBox17->Visible = false;
		textBox18->Visible = false;
		textBox19->Visible = false;
		textBox20->Visible = false;
		textBox21->Visible = false;
		textBox22->Visible = false;
		textBox23->Visible = false;

		label18->Visible = false;
		label19->Visible = false;
		label20->Visible = false;
		label21->Visible = false;
		label2->Visible = false;
		label22->Visible = false;
		label23->Visible = false;
		label24->Visible = false;
		label25->Visible = false;

		label14->Visible = false;
		label15->Visible = false;
		label16->Visible = false;

		textBox11->Visible = false;
		textBox12->Visible = false;
		textBox13->Visible = false;
		comboBox4->Visible = false;
	}
}

private: System::Void button6_Click(System::Object^ sender, System::EventArgs^ e) {
	if (comboBox1->Text == "Estudiante")
	{
		int nuevo = Convert::ToInt32(textBox3->Text);
		int cont;
		int indice = Convert::ToInt32(listDPIE->Items->Count);
		for (int i = 0; i < indice; i++)
		{
			int compa = Convert::ToInt32(listDPIE->Items[i]);
			if (nuevo == compa)
			{
				cont = i;
				listNombreE->Items->RemoveAt(cont);
				listApellidoE->Items->RemoveAt(cont);
				listDPIE->Items->RemoveAt(cont);
				listGrado->Items->RemoveAt(cont);
				listCarrera->Items->RemoveAt(cont);
				listAnio->Items->RemoveAt(cont);
				listC1E->Items->RemoveAt(cont);
				listC2E->Items->RemoveAt(cont);
				listBoxC3->Items->RemoveAt(cont);
				listC4->Items->RemoveAt(cont);
				listC5->Items->RemoveAt(cont);
				listNC1E->Items->RemoveAt(cont);
				listNC2E->Items->RemoveAt(cont);
				listNC3->Items->RemoveAt(cont);
				listNC4->Items->RemoveAt(cont);
				listNC5->Items->RemoveAt(cont);
				listCentroTrabajo->Items->RemoveAt(cont);
				listEstudio->Items->RemoveAt(cont);
				listPromE->Items->RemoveAt(cont);
				listfacultad->Items->RemoveAt(cont);
				listMuestraVF->Items->RemoveAt(cont);
			}
		}
		int conprom = 0;
		String^ nombre;
		String^ Apellido;
		int DPI;
		String^ grado;
		String^ carrera;
		int anio;
		String^ curso1;
		String^ curso2;
		String^ curso3;
		String^ curso4;
		String^ curso5;
		String^ facultad;
		double notac1;
		double notac2;
		double notac3;
		double notac4;
		double notac5;
		String^ CTrabajo;
		String^ TEstudio;
		double prom;

		if (comboBox2->Text == "Pre-Grado")
		{
			anio = Convert::ToUInt32(textBox6->Text);
			if (textBox9->Text == "")
			{
				notac1 = 0;
			}
			else
			{
				notac1 = Convert::ToDouble(textBox9->Text);
				conprom++;
			}

			if (textBox10->Text == "")
			{
				notac2 = 0;
			}
			else
			{
				notac2 = Convert::ToDouble(textBox10->Text);
				conprom++;
			}

			if (textBox26->Text == "")
			{
				notac3 = 0;
			}
			else
			{
				notac3 = Convert::ToDouble(textBox26->Text);
				conprom++;
			}

			if (textBox27->Text == "")
			{
				notac4 = 0;
			}
			else
			{
				notac4 = Convert::ToDouble(textBox27->Text);
				conprom++;
			}

			if (textBox28->Text == "")
			{
				notac5 = 0;
			}
			else
			{
				notac5 = Convert::ToDouble(textBox28->Text);
				conprom++;
			}
			nombre = textBox1->Text;
			Apellido = textBox2->Text;
			DPI = Convert::ToInt32(textBox3->Text);
			grado = comboBox2->Text;
			carrera = textBox5->Text;
			curso1 = textBox7->Text;

			if (facultad == "")
			{
				facultad = "Desconocida";
			}
			else
			{
				facultad = textBox29->Text;
			}
			if (textBox7->Text == "")
			{
				curso1 = "No Asignado";
			}
			else
			{
				curso1 = textBox7->Text;
			}
			if (textBox8->Text == "")
			{
				curso2 = "No Asignado";
			}
			else
			{
				curso2 = textBox8->Text;
			}

			if (textBox14->Text == "")
			{
				curso3 = "No Asignado";
			}
			else
			{
				curso3 = textBox14->Text;
			}

			if (textBox24->Text == "")
			{
				curso4 = "No Asignado";
			}
			else
			{
				curso4 = textBox24->Text;
			}

			if (textBox25->Text == "")
			{
				curso5 = "No Asignado";
			}
			else {
				curso5 = textBox25->Text;
			}
			prom = (notac1 + notac2 + notac3 + notac4 + notac5) / conprom;
			CTrabajo = "No aplica";
			TEstudio = "No aplica";

		}
		else if (comboBox2->Text == "Pos-Grado")
		{

			nombre = textBox1->Text;
			Apellido = textBox2->Text;
			DPI = Convert::ToInt32(textBox3->Text);
			grado = comboBox2->Text;
			CTrabajo = textBox4->Text;
			TEstudio = comboBox3->Text;
			carrera = "No aplica";
			anio = 0;

			if (textBox7->Text == "")
			{
				curso1 = "No Asignado";
			}
			else
			{
				curso1 = textBox7->Text;

			}

			if (textBox8->Text == "")
			{
				curso2 = "No Asignado";
			}
			else
			{
				curso2 = textBox8->Text;

			}

			if (textBox14->Text == "")
			{
				curso3 = "No Asignado";
			}
			else
			{
				curso3 = textBox14->Text;

			}

			if (textBox24->Text == "")
			{
				curso4 = "No Asignado";
			}
			else
			{
				curso4 = textBox24->Text;

			}

			if (textBox25->Text == "")
			{
				curso5 = "No Asignado";
			}
			else
			{
				curso5 = textBox25->Text;
			}

			if (textBox9->Text == "")
			{
				notac1 = 0;
			}
			else
			{
				notac1 = Convert::ToDouble(textBox9->Text);
				conprom++;
			}

			if (textBox10->Text == "")
			{
				notac2 = 0;
			}
			else
			{
				notac2 = Convert::ToDouble(textBox10->Text);
				conprom++;
			}

			if (textBox26->Text == "")
			{
				notac3 = 0;
			}
			else
			{
				notac3 = Convert::ToDouble(textBox26->Text);
				conprom++;
			}

			if (textBox27->Text == "")
			{
				notac4 = 0;
			}
			else
			{
				notac4 = Convert::ToDouble(textBox27->Text);
				conprom++;
			}

			if (textBox28->Text == "")
			{
				notac5 = 0;
			}
			else
			{
				notac5 = Convert::ToDouble(textBox28->Text);
				conprom++;
			}
			prom = (notac1 + notac2 + notac3 + notac4 + notac5) / conprom;
			facultad = textBox29->Text;
			if (facultad == "")
			{
				facultad = "Desconocida";
			}
		}

		String^ Muestra = nombre + " - " + Apellido + " - " + DPI + " - " + grado;
		listNombreE->Items->Add(nombre);
		listApellidoE->Items->Add(Apellido);
		listDPIE->Items->Add(DPI);
		listGrado->Items->Add(grado);
		listCarrera->Items->Add(carrera);
		listAnio->Items->Add(anio);
		listC1E->Items->Add(curso1);
		listC2E->Items->Add(curso2);
		listBoxC3->Items->Add(curso3);
		listC4->Items->Add(curso4);
		listC5->Items->Add(curso5);
		listNC1E->Items->Add(notac1);
		listNC2E->Items->Add(notac2);
		listNC3->Items->Add(notac3);
		listNC4->Items->Add(notac4);
		listNC5->Items->Add(notac5);
		listCentroTrabajo->Items->Add(CTrabajo);
		listEstudio->Items->Add(TEstudio);
		listPromE->Items->Add(prom);
		listfacultad->Items->Add(facultad);
		listMuestraVF->Items->Add(Muestra);

	}
	else if (comboBox1->Text == "Trabajdor")
	{
		int cont;
		int indice2 = Convert::ToInt32(listBox3->Items->Count);
		int nuevo2 = Convert::ToInt32(textBox13->Text);
		for (int i = 0; i < cont; i++)
		{
			int compa2 = Convert::ToInt32(listDPIE->Items[i]);
			if (nuevo2 == compa2)
			{
				cont = i;
				listBox1->Items->RemoveAt(cont);
				listBox3->Items->RemoveAt(cont);
				listBox2->Items->RemoveAt(cont);
				listBox4->Items->RemoveAt(cont);
				listBox5->Items->RemoveAt(cont);
				listBox6->Items->RemoveAt(cont);
				listBox7->Items->RemoveAt(cont);
				listBox8->Items->RemoveAt(cont);
				listBox9->Items->RemoveAt(cont);
				listBox10->Items->RemoveAt(cont);
				listBox11->Items->RemoveAt(cont);
				listBox12->Items->RemoveAt(cont);
				listBox13->Items->RemoveAt(cont);
				listBox14->Items->RemoveAt(cont);
			}
		}
		String^ nombret;
		String^ apellidot;
		int dpit;
		String^ puesto;
		double salario;
		int antiguo;
		String^ departamento;
		String^ Curso1;
		String^ Curso2;
		String^ Curso3;
		String^ Curso4;
		String^ Curso5;
		String^ Cargo;
		if (comboBox4->Text == "Docente")
		{
			nombret = textBox11->Text;
			apellidot = textBox12->Text;
			dpit = Convert::ToInt32(textBox13->Text);
			puesto = comboBox4->Text;
			salario = Convert::ToDouble(textBox15->Text);
			antiguo = Convert::ToInt32(textBox16->Text);
			departamento = textBox17->Text;
			if (textBox18->Text == "")
			{
				Curso1 = "No Asignado";
			}
			else
			{
				Curso1 = textBox18->Text;
			}

			if (textBox19->Text == "")
			{
				Curso2 = "No Asignado";
			}
			else
			{
				Curso2 = textBox19->Text;
			}

			if (textBox21->Text == "")
			{
				Curso3 = "No Asignado";
			}
			else
			{
				Curso3 = textBox21->Text;
			}

			if (textBox22->Text == "")
			{
				Curso4 = "No Asignado";
			}
			else
			{
				Curso4 = textBox22->Text;
			}

			if (textBox23->Text == "")
			{
				Curso5 = "No Asignado";
			}
			else
			{
				Curso5 = textBox23->Text;
			}
			Cargo = "Docente";
		}
		else if (comboBox4->Text == "Empleado")
		{

			nombret = textBox11->Text;
			apellidot = textBox12->Text;
			dpit = Convert::ToInt32(textBox13->Text);
			puesto = comboBox4->Text;
			salario = Convert::ToDouble(textBox15->Text);
			antiguo = Convert::ToInt32(textBox16->Text);
			departamento = textBox17->Text;
			Cargo = textBox20->Text;
			Curso1 = "No Aplica";
			Curso2 = "No Aplica";
			Curso3 = "No Aplica";
			Curso4 = "No Aplica";
			Curso5 = "No Aplica";

		}

		String^ Muestra = nombret + " - " + apellidot + " - " + dpit + " - " + puesto;
		listBox1->Items->Add(nombret);
		listBox2->Items->Add(apellidot);
		listBox3->Items->Add(dpit);
		listBox4->Items->Add(puesto);
		listBox5->Items->Add(salario);
		listBox6->Items->Add(antiguo);
		listBox7->Items->Add(departamento);
		listBox8->Items->Add(Curso1);
		listBox9->Items->Add(Curso2);
		listBox10->Items->Add(Curso3);
		listBox11->Items->Add(Curso4);
		listBox12->Items->Add(Curso5);
		listBox13->Items->Add(Cargo);
		listBox14->Items->Add(Muestra);


	}



	textBox1->Text = "";
	textBox2->Text = "";
	textBox3->Text = "";
	textBox1->Text = "";
	textBox2->Text = "";
	textBox3->Text = "";
	textBox4->Text = "";
	textBox5->Text = "";
	textBox6->Text = "";
	textBox7->Text = "";
	textBox8->Text = "";
	textBox9->Text = "";
	textBox10->Text = "";
	textBox11->Text = "";
	textBox12->Text = "";
	textBox13->Text = "";
	textBox14->Text = "";
	textBox15->Text = "";
	textBox16->Text = "";
	textBox17->Text = "";
	textBox18->Text = "";
	textBox19->Text = "";
	textBox20->Text = "";
	textBox21->Text = "";
	textBox22->Text = "";
	textBox23->Text = "";
	textBox24->Text = "";
	textBox25->Text = "";
	textBox26->Text = "";
	textBox27->Text = "";
	textBox28->Text = "";
	textBox29->Text = "";
	textBox28->Text = "";
	textBox29->Text = "";
	textBox14->Visible = false;
	label9->Visible = false;
	textBox4->Visible = false;
	comboBox3->Visible = false;
	label11->Visible = false;
	label17->Visible = false;
	textBox14->Visible = false;
	label11->Visible = false;
	label12->Visible = false;
	label13->Visible = false;
	label7->Visible = false;
	label10->Visible = false;
	label8->Visible = false;
	label12->Visible = false;
	textBox5->Visible = false;
	textBox6->Visible = false;
	textBox7->Visible = false;
	textBox8->Visible = false;
	textBox9->Visible = false;
	textBox10->Visible = false;
	label17->Visible = false;
	textBox14->Visible = false;
	textBox1->Visible = false;
	textBox2->Visible = false;
	textBox3->Visible = false;
	label4->Visible = false;
	label5->Visible = false;
	label6->Visible = false;
	comboBox2->Visible = false;

	label32->Visible = false;
	textBox29->Visible = false;
	textBox14->Visible = false;
	textBox24->Visible = false;
	textBox25->Visible = false;
	label17->Visible = false;
	label27->Visible = false;
	label26->Visible = false;
	label28->Visible = false;
	label29->Visible = false;
	label31->Visible = false;
	textBox26->Visible = false;
	textBox27->Visible = false;
	textBox28->Visible = false;

	textBox15->Visible = false;
	textBox16->Visible = false;
	textBox17->Visible = false;
	textBox18->Visible = false;
	textBox19->Visible = false;
	textBox20->Visible = false;
	textBox21->Visible = false;
	textBox22->Visible = false;
	textBox23->Visible = false;

	label18->Visible = false;
	label19->Visible = false;
	label20->Visible = false;
	label21->Visible = false;
	label2->Visible = false;
	label22->Visible = false;
	label23->Visible = false;
	label24->Visible = false;
	label25->Visible = false;

	label14->Visible = false;
	label15->Visible = false;
	label16->Visible = false;

	textBox11->Visible = false;
	textBox12->Visible = false;
	textBox13->Visible = false;
	comboBox4->Visible = false;
	label37->Visible = false;
	label35->Visible = false;

}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	if (comboBox1->Text == "Estudiante")
	{
		int cont = listMuestraVF->Items->Count - 1;
		listNombreE->Items->RemoveAt(cont);
		listApellidoE->Items->RemoveAt(cont);
		listDPIE->Items->RemoveAt(cont);
		listGrado->Items->RemoveAt(cont);
		listCarrera->Items->RemoveAt(cont);
		listAnio->Items->RemoveAt(cont);
		listC1E->Items->RemoveAt(cont);
		listC2E->Items->RemoveAt(cont);
		listBoxC3->Items->RemoveAt(cont);
		listC4->Items->RemoveAt(cont);
		listC5->Items->RemoveAt(cont);
		listNC1E->Items->RemoveAt(cont);
		listNC2E->Items->RemoveAt(cont);
		listNC3->Items->RemoveAt(cont);
		listNC4->Items->RemoveAt(cont);
		listNC5->Items->RemoveAt(cont);
		listCentroTrabajo->Items->RemoveAt(cont);
		listEstudio->Items->RemoveAt(cont);
		listPromE->Items->RemoveAt(cont);
		listfacultad->Items->RemoveAt(cont);
		listMuestraVF->Items->RemoveAt(cont);
		textBox14->Visible = false;
		label9->Visible = false;
		textBox4->Visible = false;
		comboBox3->Visible = false;
		label11->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		label11->Visible = false;
		label12->Visible = false;
		label13->Visible = false;
		label7->Visible = false;
		label10->Visible = false;
		label8->Visible = false;
		label12->Visible = false;
		textBox5->Visible = false;
		textBox6->Visible = false;
		textBox7->Visible = false;
		textBox8->Visible = false;
		textBox9->Visible = false;
		textBox10->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		textBox1->Visible = false;
		textBox2->Visible = false;
		textBox3->Visible = false;
		label4->Visible = false;
		label5->Visible = false;
		label6->Visible = false;
		comboBox2->Visible = false;

		label32->Visible = false;
		textBox29->Visible = false;
		textBox14->Visible = false;
		textBox24->Visible = false;
		textBox25->Visible = false;
		label17->Visible = false;
		label27->Visible = false;
		label26->Visible = false;
		label28->Visible = false;
		label29->Visible = false;
		label31->Visible = false;
		textBox26->Visible = false;
		textBox27->Visible = false;
		textBox28->Visible = false;

		textBox15->Visible = false;
		textBox16->Visible = false;
		textBox17->Visible = false;
		textBox18->Visible = false;
		textBox19->Visible = false;
		textBox20->Visible = false;
		textBox21->Visible = false;
		textBox22->Visible = false;
		textBox23->Visible = false;

		label18->Visible = false;
		label19->Visible = false;
		label20->Visible = false;
		label21->Visible = false;
		label2->Visible = false;
		label22->Visible = false;
		label23->Visible = false;
		label24->Visible = false;
		label25->Visible = false;
		label37->Visible = false;
		label35->Visible = false;

	}
	else
	{
		int cont = listBox1->Items->Count - 1;
		listBox1->Items->RemoveAt(cont);
		listBox3->Items->RemoveAt(cont);
		listBox2->Items->RemoveAt(cont);
		listBox4->Items->RemoveAt(cont);
		listBox5->Items->RemoveAt(cont);
		listBox6->Items->RemoveAt(cont);
		listBox7->Items->RemoveAt(cont);
		listBox8->Items->RemoveAt(cont);
		listBox9->Items->RemoveAt(cont);
		listBox10->Items->RemoveAt(cont);
		listBox11->Items->RemoveAt(cont);
		listBox12->Items->RemoveAt(cont);
		listBox13->Items->RemoveAt(cont);
		listBox14->Items->RemoveAt(cont);
		textBox14->Visible = false;
		label9->Visible = false;
		textBox4->Visible = false;
		comboBox3->Visible = false;
		label11->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		label11->Visible = false;
		label12->Visible = false;
		label13->Visible = false;
		label7->Visible = false;
		label10->Visible = false;
		label8->Visible = false;
		label12->Visible = false;
		textBox5->Visible = false;
		textBox6->Visible = false;
		textBox7->Visible = false;
		textBox8->Visible = false;
		textBox9->Visible = false;
		textBox10->Visible = false;
		label17->Visible = false;
		textBox14->Visible = false;
		textBox1->Visible = false;
		textBox2->Visible = false;
		textBox3->Visible = false;
		label4->Visible = false;
		label5->Visible = false;
		label6->Visible = false;
		comboBox2->Visible = false;

		label32->Visible = false;
		textBox29->Visible = false;
		textBox14->Visible = false;
		textBox24->Visible = false;
		textBox25->Visible = false;
		label17->Visible = false;
		label27->Visible = false;
		label26->Visible = false;
		label28->Visible = false;
		label29->Visible = false;
		label31->Visible = false;
		textBox26->Visible = false;
		textBox27->Visible = false;
		textBox28->Visible = false;

		textBox15->Visible = false;
		textBox16->Visible = false;
		textBox17->Visible = false;
		textBox18->Visible = false;
		textBox19->Visible = false;
		textBox20->Visible = false;
		textBox21->Visible = false;
		textBox22->Visible = false;
		textBox23->Visible = false;

		label18->Visible = false;
		label19->Visible = false;
		label20->Visible = false;
		label21->Visible = false;
		label2->Visible = false;
		label22->Visible = false;
		label23->Visible = false;
		label24->Visible = false;
		label25->Visible = false;
		label14->Visible = false;
		label15->Visible = false;
		label16->Visible = false;
		textBox11->Visible = false;
		textBox12->Visible = false;
		textBox13->Visible = false;
		comboBox4->Visible = false;
		label37->Visible = false;
		label35->Visible = false;

	}
}
private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	if (comboBox1->SelectedItem == "Estudiante")
	{
		label35->Visible = true;
		textBox1->Visible = true;
		textBox2->Visible = true;
		textBox3->Visible = true;
		label4->Visible = true;
		label5->Visible = true;
		label6->Visible = true;
		comboBox2->Visible = true;

		label23->Visible = false;
		label24->Visible = false;
		label25->Visible = false;
		textBox21->Visible = false;
		textBox22->Visible = false;
		textBox23->Visible = false;


		label2->Visible = false;
		label22->Visible = false;
		textBox20->Visible = false;
		label18->Visible = false;
		label19->Visible = false;
		label20->Visible = false;
		label21->Visible = false;
		textBox15->Visible = false;
		textBox16->Visible = false;
		textBox17->Visible = false;
		textBox18->Visible = false;
		textBox19->Visible = false;
		label14->Visible = false;
		label15->Visible = false;
		label16->Visible = false;
		textBox11->Visible = false;
		textBox12->Visible = false;
		textBox13->Visible = false;
		comboBox4->Visible = false;


		label2->Visible = false;
		label18->Visible = false;
		label19->Visible = false;
		label22->Visible = false;
		label20->Visible = false;
		label21->Visible = false;
		label23->Visible = false;
		label24->Visible = false;
		label25->Visible = false;

		textBox15->Visible = false;
		textBox16->Visible = false;
		textBox17->Visible = false;
		textBox20->Visible = false;
		textBox18->Visible = false;
		textBox19->Visible = false;
		textBox21->Visible = false;
		textBox22->Visible = false;
		textBox23->Visible = false;

		label37->Visible = false;
	}
	else
	{
		label37->Visible = true;
		label14->Visible = true;
		label15->Visible = true;
		label16->Visible = true;
		textBox11->Visible = true;
		textBox12->Visible = true;
		textBox13->Visible = true;
		comboBox4->Visible = true;


		textBox1->Visible = false;
		textBox2->Visible = false;
		textBox3->Visible = false;
		label4->Visible = false;
		label5->Visible = false;
		label6->Visible = false;
		comboBox2->Visible = false;
		comboBox3->Visible = false;

		label10->Visible = false;
		label9->Visible = false;
		label32->Visible = false;
		label7->Visible = false;
		label8->Visible = false;
		label17->Visible = false;
		label26->Visible = false;
		label27->Visible = false;
		label12->Visible = false;
		label13->Visible = false;
		label28->Visible = false;
		label29->Visible = false;
		label31->Visible = false;
		label35->Visible = false;
		label11->Visible = false;

		textBox6->Visible = false;
		textBox5->Visible = false;
		textBox29->Visible = false;
		textBox7->Visible = false;
		textBox8->Visible = false;
		textBox9->Visible = false;
		textBox10->Visible = false;
		textBox14->Visible = false;
		textBox26->Visible = false;
		textBox24->Visible = false;
		textBox25->Visible = false;
		textBox27->Visible = false;
		textBox28->Visible = false;

	}
}
private: System::Void comboBox3_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	if (comboBox2->SelectedItem == "Pre-Grado")
	{
		label11->Visible = true;
		label12->Visible = true;
		label13->Visible = true;
		label7->Visible = true;
		label10->Visible = true;
		label8->Visible = true;
		label12->Visible = true;
		textBox5->Visible = true;
		textBox6->Visible = true;
		textBox7->Visible = true;
		textBox8->Visible = true;
		textBox9->Visible = true;
		textBox10->Visible = true;
		textBox14->Visible = false;
		label9->Visible = false;
		textBox4->Visible = false;
		comboBox3->Visible = false;
		label11->Visible = true;
		label17->Visible = false;
		textBox14->Visible = false;
		label32->Visible = true;
		textBox29->Visible = true;
		textBox14->Visible = true;
		textBox24->Visible = true;
		textBox25->Visible = true;
		label17->Visible = true;
		label27->Visible = true;
		label26->Visible = true;
		label28->Visible = true;
		label29->Visible = true;
		label31->Visible = true;
		textBox26->Visible = true;
		textBox27->Visible = true;
		textBox28->Visible = true;

	}
	else
	{

		label8->Visible = true;
		label17->Visible = true;
		label26->Visible = true;
		label27->Visible = true;
		label12->Visible = true;
		label13->Visible = true;
		label28->Visible = true;
		label29->Visible = true;
		label31->Visible = true;

		label9->Visible = true;
		textBox4->Visible = true;
		comboBox3->Visible = true;
		textBox14->Visible = true;
		label11->Visible = false;
		label7->Visible = true;

		label10->Visible = false;

		label12->Visible = true;
		textBox5->Visible = false;
		textBox6->Visible = false;


		textBox9->Visible = true;
		textBox10->Visible = true;
		label17->Visible = true;
		textBox14->Visible = true;
		label32->Visible = true;
		textBox29->Visible = true;
		textBox7->Visible = true;
		textBox8->Visible = true;
		textBox14->Visible = true;
		textBox24->Visible = true;
		textBox25->Visible = true;
		textBox26->Visible = true;
		textBox27->Visible = true;
		textBox28->Visible = true;
	}
}
private: System::Void comboBox4_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	if (comboBox4->SelectedItem == "Docente")
	{
		label22->Visible = false;
		label2->Visible = true;
		label20->Visible = true;
		label21->Visible = true;
		textBox15->Visible = true;
		textBox16->Visible = true;
		textBox17->Visible = true;
		textBox18->Visible = true;
		textBox19->Visible = true;

		label18->Visible = true;
		label23->Visible = true;
		label24->Visible = true;
		label25->Visible = true;
		textBox21->Visible = true;
		textBox22->Visible = true;
		textBox23->Visible = true;
		textBox20->Visible = false;
		label19->Visible = true;


	}
	else if (comboBox4->SelectedItem == "Empleado")
	{
		label22->Visible = true;
		textBox20->Visible = true;
		label2->Visible = true;
		textBox15->Visible = true;
		label20->Visible = false;
		label21->Visible = false;


		textBox16->Visible = true;
		textBox17->Visible = true;
		textBox20->Visible = true;

		textBox18->Visible = true;
		textBox19->Visible = true;
		textBox15->Visible = true;
		label22->Visible = true;

		label23->Visible = false;
		label24->Visible = false;
		label25->Visible = false;
		textBox21->Visible = false;
		textBox22->Visible = false;
		textBox23->Visible = false;
		label18->Visible = true;
		label19->Visible = true;
		textBox18->Visible = false;
		textBox19->Visible = false;
	}
}
private: System::Void listMuestraVF_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	int a = listMuestraVF->SelectedIndex;
	String^ Muestra;
	String^ C1 = listC1E->Items[a]->ToString();
	String^ C2 = listC2E->Items[a]->ToString();;
	String^ C3 = listBoxC3->Items[a]->ToString();
	String^ C4 = listC4->Items[a]->ToString();
	String^ C5 = listC5->Items[a]->ToString();
	float nota1 = Convert::ToDouble(listNC1E->Items[a]);
	float nota2 = Convert::ToDouble(listNC2E->Items[a]);
	float nota3 = Convert::ToDouble(listNC3->Items[a]);
	float nota4 = Convert::ToDouble(listNC4->Items[a]);
	float nota5 = Convert::ToDouble(listNC5->Items[a]);
	if (C1 != "No Aplica")
	{
		Muestra += " Cursos: " + C1 + " - " + nota1;
	}
	else
	{
		Muestra += ", ";
	}

	if (C2 != "No Aplica")
	{
		Muestra += " " + C2 + " - " + nota2;
	}
	else
	{
		Muestra += ", ";
	}

	if (C3 != "No Aplica")
	{
		Muestra += " " + C3 + " - " + nota3;
	}
	else
	{
		Muestra += ", ";
	}

	if (C4 != "No Aplica")
	{
		Muestra += " " + C4 + " - " + nota4;
	}
	else
	{
		Muestra += ", ";
	}

	if (C5 != "No Aplica")
	{
		Muestra += " " + C5 + " - " + nota5;
	}
	else
	{
		Muestra += ", ";
	}

	MessageBox::Show("Estudiante: " + listNombreE->Items[a] + " " + listApellidoE->Items[a] + ", DPI: " + listDPIE->Items[a] + ", Facultad: " + listfacultad->Items[a] + ", Promedio: " + listPromE->Items[a] + " " + Muestra, "Informacion Personal");
}
private: System::Void listBox14_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	int a = listBox14->SelectedIndex;
	MessageBox::Show("Trabajador: " + listBox1->Items[a] + " " + listBox2->Items[a] + ", DPI: " + listBox3->Items[a] + ", Puesto: " + listBox4->Items[a] + ", Salario: Q" + listBox5->Items[a], "Informacion Personal");
}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	int te = Convert::ToInt32(listDPIE->Items->Count);
	int tt = Convert::ToInt32(listBox3->Items->Count);
	int busqueda = Convert::ToInt32(textBox30->Text);
	for (int i = 0; i < te; i++)
	{
		int compa = Convert::ToInt32(listDPIE->Items[i]);
		if (busqueda == compa)
		{
			MessageBox::Show("Nombre: " + listNombreE->Items[i] + " " + listApellidoE->Items[i], "Informacion de Busqueda");
		}
	}
	for (int j = 0; j < tt; j++)
	{
		int compa2 = Convert::ToInt32(listBox3->Items[j]);
		if (busqueda == compa2)
		{
			MessageBox::Show("Nombre: " + listBox1->Items[j] + " " + listBox2->Items[j], "Informacion de Busqueda");
		}

	}

	textBox30->Text = "";
}

private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {

	string texto1;
	String^ texto;
	int count = listEstudio->Items->Count;
	for (int i = 0; i < count; i++)
	{
		String^ compa = listEstudio->Items[i]->ToString();
		if (compa == "Doctorado")
		{
			texto += "\n\r" + listApellidoE->Items[i]->ToString() + " " + listNombreE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			textBox31->Text = texto;
			String^ textovf = textBox31->Text;
			MarshalString(textovf, texto1);
		}
	}
	string nombre = "Lista de Estudiantes de Doctorado";
	fstream archivoNuevo;
	archivoNuevo.open(nombre, ios::out);
	if (!archivoNuevo) {
		MessageBox::Show("El archivo no ha sido creado");
	}
	else {
		archivoNuevo << texto1;
		archivoNuevo.close();
		MessageBox::Show("El archivo se ha creado con exito");
	}
	textBox31->Text = "";


}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	int cont = Convert::ToInt32(listBox5->Items->Count);
	double prom = 0;
	for (int i = 0; i < cont; i++)
	{
		double sumando = Convert::ToDouble(listBox5->Items[i]);
		prom = prom + sumando;
	}
	prom = prom / cont;
	MessageBox::Show("El Salario promedio es de: Q" + prom);
}
private: System::Void button7_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ texto;
	int count = listEstudio->Items->Count;
	int contadore = 0;
	for (int i = 0; i < count; i++)
	{
		String^ compa = listEstudio->Items[i]->ToString();
		if (compa == "Maestria")
		{
			texto += "\n\r" + listNombreE->Items[i]->ToString() + " " + listApellidoE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			contadore++;
		}
	}
	MessageBox::Show("Actualmente hay: " + contadore + " Estudiantes de Maestr�a" + texto, "Estudiantes de Maestr�a");

}

private: System::Void button8_Click(System::Object^ sender, System::EventArgs^ e) {
	if (textBox32->Text != "")
	{


		String^ curso = textBox32->Text;
		String^ estudiante;
		int limite = Convert::ToInt32(listBox8->Items->Count);
		int contadorprof = 0;
		String^ Mensaje;
		for (int i = 0; i < limite; i++)
		{
			if (curso == listBox8->Items[i]->ToString())
			{
				contadorprof++;
			}
			else if (curso == listBox9->Items[i]->ToString())
			{
				contadorprof++;
			}
			else if (curso == listBox10->Items[i]->ToString())
			{
				contadorprof++;
			}
			else if (curso == listBox11->Items[i]->ToString())
			{
				contadorprof++;
			}
			else if (curso == listBox12->Items[i]->ToString())
			{
				contadorprof++;
			}
		}
		int count = Convert::ToInt32(listC1E->Items->Count);
		for (int i = 0; i < count; i++)
		{
			String^ compa = listC1E->Items[i]->ToString();
			if (compa == curso)
			{
				estudiante += "\n\r" + listNombreE->Items[i]->ToString() + " " + listApellidoE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			}
		}
		int count2 = Convert::ToInt32(listC2E->Items->Count);
		for (int i = 0; i < count2; i++)
		{
			String^ compa = listC2E->Items[i]->ToString();
			if (compa == curso)
			{
				estudiante += "\n\r" + listNombreE->Items[i]->ToString() + " " + listApellidoE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			}
		}
		int count3 = Convert::ToInt32(listBoxC3->Items->Count);
		for (int i = 0; i < count3; i++)
		{
			String^ compa = listBoxC3->Items[i]->ToString();
			if (compa == curso)
			{
				estudiante += "\n\r" + listNombreE->Items[i]->ToString() + " " + listApellidoE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			}
		}
		int count4 = Convert::ToInt32(listC4->Items->Count);
		for (int i = 0; i < count4; i++)
		{
			String^ compa = listC4->Items[i]->ToString();
			if (compa == curso)
			{
				estudiante += "\n\r" + listNombreE->Items[i]->ToString() + " " + listApellidoE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			}
		}
		int count5 = Convert::ToInt32(listC5->Items->Count);
		for (int i = 0; i < count5; i++)
		{
			String^ compa = listC5->Items[i]->ToString();
			if (compa == curso)
			{
				estudiante += "\n\r" + listNombreE->Items[i]->ToString() + " " + listApellidoE->Items[i]->ToString() + " DPI: " + listDPIE->Items[i]->ToString() + '\n\r';
			}
		}
		MessageBox::Show("Profesores que lo imparten: " + contadorprof + ", Lista de estudiantes que lo reciben: " + estudiante, "Informacion de Cursos Activos");
	}
	else
	{
		MessageBox::Show("Ingrese un curso activo", "Informacion de Cursos");
	}
	textBox32->Text = "";
}
private: System::Void button9_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ nombre = textBox33->Text;
	int count = Convert::ToInt32(listNC1E->Items->Count);
	int indice;
	double prom = 0;
	int max = 0;
	int contador = 0;
	for (int i = 0; i < count; i++)
	{
		if (nombre == listNombreE->Items[i]->ToString())
		{
			indice = i;
		}
	}
	int nota1 = Convert::ToInt32(listNC1E->Items[indice]);
	if (nota1 != 0)
	{
		contador++;
	}
	int nota2 = Convert::ToInt32(listNC2E->Items[indice]);
	if (nota2 != 0)
	{
		contador++;
	}
	int nota3 = Convert::ToInt32(listNC3->Items[indice]);
	if (nota3 != 0)
	{
		contador++;
	}
	int nota4 = Convert::ToInt32(listNC4->Items[indice]);
	if (nota4 != 0)
	{
		contador++;
	}
	int nota5 = Convert::ToInt32(listNC5->Items[indice]);
	if (nota5 != 0)
	{
		contador++;
	}
	if (nota1 > nota2)
	{
		max = nota1;
	}
	else
	{
		max = nota2;
	}
	if (nota3 > max)
	{
		max = nota3;
	}
	if (max < nota4)
	{
		max = nota4;
	}
	if (nota5 > max)
	{
		max = nota5;
	}
	prom = (nota1 + nota2 + nota3 + nota4 + nota5) / contador;
	MessageBox::Show("Nota mas alta: " + max + " El Promedio es: " + prom, "Informacion de: " + nombre + " " + listApellidoE->Items[indice]->ToString());

	textBox33->Text = "";
}
private: System::Void comboBox2_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
	if (comboBox2->SelectedItem == "Pre-Grado")
	{
		label11->Visible = true;
		label12->Visible = true;
		label13->Visible = true;
		label7->Visible = true;
		label10->Visible = true;
		label8->Visible = true;
		label12->Visible = true;
		textBox5->Visible = true;
		textBox6->Visible = true;
		textBox7->Visible = true;
		textBox8->Visible = true;
		textBox9->Visible = true;
		textBox10->Visible = true;
		textBox14->Visible = false;
		label9->Visible = false;
		textBox4->Visible = false;
		comboBox3->Visible = false;
		label11->Visible = true;
		label17->Visible = false;
		textBox14->Visible = false;
		label32->Visible = true;
		textBox29->Visible = true;
		textBox14->Visible = true;
		textBox24->Visible = true;
		textBox25->Visible = true;
		label17->Visible = true;
		label27->Visible = true;
		label26->Visible = true;
		label28->Visible = true;
		label29->Visible = true;
		label31->Visible = true;
		textBox26->Visible = true;
		textBox27->Visible = true;
		textBox28->Visible = true;

	}
	else
	{

		label8->Visible = true;
		label17->Visible = true;
		label26->Visible = true;
		label27->Visible = true;
		label12->Visible = true;
		label13->Visible = true;
		label28->Visible = true;
		label29->Visible = true;
		label31->Visible = true;

		label9->Visible = true;
		textBox4->Visible = true;
		comboBox3->Visible = true;
		textBox14->Visible = true;
		label11->Visible = false;
		label7->Visible = true;

		label10->Visible = false;

		label12->Visible = true;
		textBox5->Visible = false;
		textBox6->Visible = false;


		textBox9->Visible = true;
		textBox10->Visible = true;
		label17->Visible = true;
		textBox14->Visible = true;
		label32->Visible = true;
		textBox29->Visible = true;
		textBox7->Visible = true;
		textBox8->Visible = true;
		textBox14->Visible = true;
		textBox24->Visible = true;
		textBox25->Visible = true;
		textBox26->Visible = true;
		textBox27->Visible = true;
		textBox28->Visible = true;
	}
}
private: System::Void button10_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void button10_Click_1(System::Object^ sender, System::EventArgs^ e) {
	groupBox1->Visible = true;
	groupBox2->Visible = true;
}
};
}